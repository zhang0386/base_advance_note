"""
递归介绍
    概述：
        方法自己调用自己的情况叫递归
    经典案例：
        1.求阶乘
        2.不死神兔，斐波那契数列。
        3.文件夹拷贝，删除等
        4.服务器文件整理
    核心要点：
        1.递归必须要有出口，否则容易造成死递归
        2.递归调用次数不能过多，否则容易造成死递归
        3.递归必须有规律
    要搞定递归，掌握两点：
        1.分析出口
        2.找规律
"""
# 求阶乘
def factorial(n):
    product = 0
    # 出口
    if n == 1:
        return 1
    product = n * factorial(n-1)
    # 规律
    return product

print(factorial(4))

# 递归入门案例
# count = 0
# def show():
#     global count
#     count += 1
#     if count <= 100:
#         print(f"我是show函数{count}")
#         show()
#
# show()