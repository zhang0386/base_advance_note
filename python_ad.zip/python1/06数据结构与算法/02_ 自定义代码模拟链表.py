"""
案例：自定义代码模拟链表

链表介绍：
    概述：
        它属于数据结构之 线性结构的一种，每个节点都只能有 1个前驱 和 1个后继节点
    作用：
        用于优化顺序表的弊端(如果没有足够的连续的内存空间，会导致扩容失败)
        链表扩容时，有地就行，连不连续无所谓
    组成：
        由 节点 组成，其中节点由 元素域(数值域) 和 链接域(地址域) 组成
    分类：
        根据 节点类型不同，链表主要分为：
        单向链表：节点由1个数值域 和 1个地址域组成，前边节点的地址域存储的是后继节点的地址，最后1个节点的地址域是None
        单向循环链表
        双向链表
        双向循环链表

自定义代码模块链表，思路分析：
    1.自定义SingleNode类，表示 节点类
        属性：
            item    数值域(元素域)
            next    地址域(链接域)

    2.自定义SingleLinkedList类，表示： 链表
        属性：
            head 表示头结点，指向第1个节点
        行为：
            is_empty(self) 链表是否为空
            length(self)    链表长度
            travel(self. )  遍历整个链表
            add(self,item)  链表头部添加元素
            append(self,item) 链表尾部添加元素
            insert(self, pos, item) 指定位置添加元素
            remove(self,item) 删除节点
            search(self,item) 查找节点是否存在

"""
from itertools import count


# 1.自定义SingleNode类，表示 节点类
class SingleNode:
    def __init__(self,item):
        self.item = item        # 数值域(元素域)
        self.next = None        # 地址域(链接域)

# 1.自定义SingleLinkedList类，表示： 链表
class SingleLinkedList:
    def __init__(self,node=None):
        self.head = node

    # 2.is_empty(self) 链表是否为空
    def is_empty(self):
        # 思路：判断头结点是否为None，如果为None，则链表为空
        # 写法1：if else
        # if self.head == None:
        #     return True
        # else:
        #     return False

        # 写法2：三元表达式
        # return True if self.head is None else False

        # 写法3：最终版
        return self.head is None

    # 3.length(self)    链表长度
    def length(self):
        # 3.1创建游标(表示当前结点)，默认从头结点开始
        cur = self.head
        # 3.2定义计数器
        count = 0
        # 3.3开始遍历，只要当前结点不为空，就一直循环
        while cur is not None:
            # 3.4计数器 + 1，然后，cur指向下一个结点
            count += 1
            cur = cur.next
        # 返回链表长度
        return count

    # 4.travel(self. )  遍历整个链表
    def travel(self):
        # 4.1创建游标，默认从头结点开始
        cur = self.head
        # 4.2只要当前结点不为空，就一直循环
        while cur is not None:
            # 4.3打印当前结点的数值域
            print(f"数值域： {cur.item}")
            # 4.4修改当前节点，然后指向下一个结点
            cur = cur.next


    # 5.add(self,item)  链表头部添加元素
    def add(self,item):
        # 5.1创建新节点
        new_node = SingleNode(item)
        # 5.2设置新节点指向头结点
        new_node.next = self.head
        # 5.3设置头结点指向新节点
        self.head = new_node

    # 6.append(self,item) 链表尾部添加元素
    def append(self,item):
        # 创建新节点
        new_node = SingleNode(item)
        # 若链表为空，直接设置当前结点为头结点
        if self.is_empty():
            self.head = new_node
        # 不为空，则指向下一个结点
        else:
            # 走到这里说明链表不为空，需要找到尾结点
            # 创建游标(表示当前节点)，默认从头结点开始
            cur = self.head
            # 开始遍历，只要当前结点不为空，就一直循环
            while cur.next is not None:
                cur = cur.next
            cur.next = new_node


    # 7.insert(self, pos, item) 指定位置添加元素
    def insert(self,pos,item):
        # 7.1判断索引是否越界，如果 ≤ 0 往前加
        if pos <= 0:
            self.add(item)
        # 7.2如果索引是 ≥ 长度的，就往后加
        elif pos >= self.length():
            self.append(item)
        else:
            # 7.3走到这里，说明索引合法，即：中间的值，需要找到插入位置前的那个元素
            # 7.4创建游标（表示当前结点），默认从头结点开始
            cur = self.head
            # 7.5定义变量，记录当前结点的位置(可以理解为索引，但不是，因为链表没有索引)
            count = 0
            # 7.6开始遍历，只要 当前结点的位置 < pos，就一直循环
            while count < pos-1:
                # 7.7  计数器+1
                cur = cur.next
                count += 1
            # 7.8cur就是插入位置前的那个结点，先封装内容为新节点
            new_node = SingleNode(item)
            # 7.9设置 新节点的地址域 指向 插入位置前的那个元素的地址域
            new_node.next = cur.next
            # 7.10设置 插入位置前的那个元素的地址域 指向 新节点
            cur.next = new_node


    # 8.remove(self,item) 删除节点
    def remove(self,item):
        # 8.1创建游标（表示当前结点），默认从头结点开始
        cur = self.head
        # 8.2定义变量，记录要删除节点的前驱结点
        per = None
        # 8.3遍历结点，查找要删除的结点
        while cur is not None:
             # 8.4判断该节点是否是要删除的结点
             if cur.item == item:
                 # 8.5如果要删除的结点为头结点
                 if cur == self.head:
                    # 8.6直接设置头结点为当前结点的下一个结点
                    self.head = cur.next
                 # 8.7如果不是头结点
                 else:
                     # 8.8设置要删除的结点的前驱结点指向当前结点的下一个结点
                     per.next = cur.next
                     cur.next = None # 删除结点，断开连接
                 # 走到这里，说明删除成功，直接返回即可，即：结束函数
                 return
             # 8.9不是要删除的结点
             else:
                 per = cur
                 cur = cur.next


    # 9.search(self,item) 查找节点是否存在
    def search(self,item):
        # 9.1创建游标（表示当前结点），默认从头结点开始
        cur = self.head
        # 9.2创建变量，记录结点的当前位置
        pos = 0
        # 9.3遍历结点，当前结点不为空就一直循环
        while cur is not None:
            pos += 1
            # 9.4找到该节点
            if cur.item == item:
                print(f"该节点存在,为第{pos}结点")
                return
            else:
                # 9.5走到这，说明没找到
                cur = cur.next
        print("该节点不存在")

if __name__ == '__main__':
    # # 测试节点类
    # node1 = SingleNode(10)
    # print(f"数值域(元素域):{node1.item}")     # 10
    # print(f"地址域(链接域):{node1.next}")     # None
    # print(f"node1对象:{node1}")               # <__main__.SingleNode object at 0x000001ED076C46A0>
    # print(f"node1的类型:{type(node1)}")    #<class '__main__.SingleNode'>
    # print('-'*34)
    #
    # # 测试链表类：
    # # my_linkedlist = SingleLinkedList()
    # my_linkedlist = SingleLinkedList(node1)
    # print(f"头结点为：{my_linkedlist.head}")
    # print(f"头结点的元素域为：{my_linkedlist.head.item}")
    # print(f"头结点的地址域为：{my_linkedlist.head.next}")

    # 2.测试is_empty函数
    # 2.1创建节点类
    node2 = SingleNode('会襄')
    # 2.2将上述的节点作为头结点，创建链表
    my_linkedlist = SingleLinkedList(node2)
    # my_linkedlist = SingleLinkedList()
    # print(f"头结点为：{my_linkedlist.head}")
    # print(f"头结点的数值域为：{my_linkedlist.head.item}")
    print('-'*23)

    # 2.3测试链表是否为空
    print(my_linkedlist.is_empty())
    print('-'*23)

    # 5.测试链表头部添加元素
    my_linkedlist.add('晴天')
    my_linkedlist.add('雨天')

    # 6.测试尾部添加结点
    my_linkedlist.append('小南瓜')
    my_linkedlist.append('小冬瓜')

    # 7.测试指定位置添加元素
    my_linkedlist.insert(0,'雷雨天')
    my_linkedlist.insert(5,'小西瓜')

    # 8.测试删除结点
    my_linkedlist.remove('雷雨天')
    my_linkedlist.remove('小西瓜')

    # 3.测试链表长度
    print(f"链表长度为：{my_linkedlist.length()}")
    print('-'*23)

    # 4.测试遍历列表
    my_linkedlist.travel()
    print('-'*23)

    # 9.测试结点是否存在
    my_linkedlist.search('雷雨天')
    my_linkedlist.search('雨天')
    my_linkedlist.search('小南瓜')
