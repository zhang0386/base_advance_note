"""
快速排序：
    解析：
        第1轮：1个分界值，假设第一个元素为分界值，次数：比该值小的放在左侧比该值大的放在右侧
        第2轮：2个分界值，上一分界值左边数据，找个分界值，上一轮右边数据找个分界值
        第3轮：4个分界值，以此类推...
        递归思想，需要每次传入 ： 链表，起始位置，末尾值
"""
# 升序1,36,13,10,25
# 定义函数：快速排序
def quick_sort(my_list,start,end):      # start:0 , end: 列表长度-1
    """
    快速排序思路，实现对列表元素排序
    :param my_list: 要操作的列表
    :param start: 操作的数据，起始索引
    :param end: 操作的数据，结束索引
    :return:
    """
    # 核心细节：如果start >= end ，递归结束，说明排好序了
    if start >= end:
        return
    # 1.1定义变量left 和 right,分别表示，分界值左右的索引
    left = start
    right = end
    # 1.2定义变量mid，表示分界值，假设列表的起始值为分界值
    mid = my_list[start]
    # 1.3具体的查找过程，只要left比right要小就一直循环
    while left < right:
        # 1.4把分界值右边 比分界值小的数据，放分界值左边
        # 1.4.1循环操作，只要分界值右边的数据比分界值大，right就-1，直到循环结束
        while my_list[right] >= mid and left < right:
            right -= 1
        # 1.4.2走到这里，说明my_list[right]比分界值小，放左侧
        my_list[left] = my_list[right]

        # 1.5把分界值左边 比分界值大的数据，放在分界值右边
        # 1.5.1循环操作，只要分界值左边的数据比分界值小，left就+1，直到循环结束
        while my_list[left] < mid and left < right:
            left += 1
        # 1.5.2走到这里，说明my_list[left]比分界值大(或者等于)，放右侧
        my_list[right] = my_list[left]
    # 1.6走到这里，循环结束，即：分界值的位置已经找到，赋值即可
    my_list[left] = mid

    # 1.7递归方式，处理分界值左侧的数据
    quick_sort(my_list,start,left - 1)

    # 1.8递归方式，处理分界值右侧的数据
    quick_sort(my_list,right + 1,end)



if __name__ == '__main__':
    # 1.创列表，记录要排序的元素
    my_list = [1,36,13,10,25]
    # 2.打印排序前的列表
    print("排序前：",my_list)
    # 3.调用函数，实现排序
    quick_sort(my_list,0,len(my_list)-1)
    # 4.打印排好的列表
    print("排序后：",my_list)