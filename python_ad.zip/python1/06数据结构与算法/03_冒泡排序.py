"""
冒泡排序：
    最优时间复杂度：O(n)
    最坏时间复杂度：O(n²)

    扩展：
        外循环的 -1 ：减少比较的轮数，提高效率
        内循环的 -1 ：为了防止索引越界
        内循环的 -i ：减少比较每轮的次数，提高效率
"""
# 升序排列：5 3 4 7 2

def bubble_sort(my_list):
    n = len(my_list)
    for i in range(n-1):
        # 细节1：定义变量，记录交换次数
        count = 0
        for j in range(n-1-i):
            if my_list[j] > my_list[j+1]:
                # 细节2：发生交换
                count += 1
                my_list[j],my_list[j+1] = my_list[j+1],my_list[j]
        # 细节3：打印交换次数
        print(f"第{i+1}轮发生{count}次交换")
        # 细节4：判断如果本轮没有发生交换，说明
        if count == 0:
            break
    print(my_list)

if __name__ == '__main__':
    # l = [5,3,6,7,2]
    l = [2, 3, 5, 7, 6]
    bubble_sort(l)
