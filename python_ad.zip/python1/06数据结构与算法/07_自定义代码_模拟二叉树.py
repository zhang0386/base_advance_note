"""
案例：自定义代码，模拟二叉树

树结构解析：
    概述：
        它属于数据结构的一种，属于 非线性结构(N个前驱，N个后继)
    特点：
        1.有且仅有1个根节点
        2.每个节点可以有1个父节点，N个子节点，根节点除外(没有父节点)
        3.没有子节点的节点叫 叶子节点
    常用分类：
        无序树：
        有序树：
        二叉树：
            完全二叉树：最后一层不满，其他都是满的
            满二叉树：都是慢的
            非完全二叉树：中间有断的
            平衡二叉树：任意节点的两个子树的高度差不超过1

    存储：
        顺序存储：既要有存储数据，又要存储节点的关系
        链式存储：采用节点(item,lchild,rchild)的方式，形成链表存储
抽取方法的快捷键：ctrl + alt + M
"""
# 1.定义Node类，表示二叉树节点
class Node:
    # 初始化属性
    def __init__(self,item):
        self.item = item            # 元素域，即：节点存储的数据
        self.lchild = None          # 左子节点
        self.rchild = None          # 右子节点

# 2.自定义BinaryTree，表示二叉树的节点
class BinaryTree:
    # 2.1初始化属性
    def __init__(self,node = None):
        self.root = node        # 根节点，类似链表的：self.head

    # 2.2定义add函数，表示添加节点
    def add(self,item):
        # 2.2.1设置新节点
        new_node = Node(item)
        # 2.2.2判断根节点是否为空，若为空，则设置根节点为新节点
        if self.root is None:
            self.root = new_node
            return      # 核心
        # 2.2.3创建队列，添加 根节点到队列
        queue = []
        queue.append(self.root)
        # 2.2.4遍历所有节点,找到空缺节点
        while True:
            # 2.2.5获取队列的第1个元素
            node = queue.pop(0)
            # 2.2.6判断左子树是否为空，若为空，则将新节点添加进去
            if node.lchild is None:
                node.lchild = new_node
                # 2.2.7结束循环
                return
            else:
                # 2.2.8把当前节点的左子树，添加到队列中
                queue.append(node.lchild)
            # 2.2.9判断右子树是否为空，若为空，则将新节点添加进去
            if node.rchild is None:
                node.rchild = new_node
                # 2.2.7结束循环
                return
            else:
                # 2.2.8把当前节点的右子树，添加到队列中
                queue.append(node.rchild)

    # 2.3定义breadth_travel()函数，表示：广度优先遍历(逐层遍历)
    def breadth_travel(self):
        # 1.判断根节点是否为空
        if self.root is None:
            return
        # 2.创建队列，把根节点放到队列中
        queue = []
        queue.append(self.root)
        # 3.循环遍历二叉树
        while len(queue) != 0:
            # 4.取出队列的第一位元素
            node = queue.pop(0)
            # 4.打印该节点的元素域
            print(node.item,end=' ')
            # 5.判断该节点的左子树是否为空，不空则添加到队列中
            if node.lchild is not None:
                queue.append(node.lchild)
            # 6.判断该节点的右子树是否为空，不空则添加到队列中
            if node.rchild is not None:
                queue.append(node.rchild)


    # 2.4定义preorder_travel()函数，表示：深度优先之先序遍历(根左右)
    def preorder_travel(self,root):
        # 1.判断根节点是否不为空，不为空就打印
        if root is not None:
            # 2.打印根节点的元素域
            print(root.item,end=' ')
            # 3.递归遍历左子树
            self.preorder_travel(root.lchild)
            # 4.递归遍历右子树
            self.preorder_travel(root.rchild)

    # 2.5定义inorder_travel()函数，表示：深度优先之中序遍历(左根右)
    def inorder_travel(self,root):
        # 1.判断根节点是否不为空，不为空就打印
        if root is not None:
            # 2.递归遍历左子树
            self.inorder_travel(root.lchild)
            # 3.打印根节点的元素域
            print(root.item, end=' ')
            # 4.递归遍历右子树
            self.inorder_travel(root.rchild)

    # 2.6定义postorder_travel()函数，表示：深度优先之后续遍历(左右根)
    def postorder_travel(self,root):
        # 1.判断根节点是否不为空，不为空就打印
        if root is not None:
            # 2.递归遍历左子树
            self.postorder_travel(root.lchild)
            # 3.递归遍历右子树
            self.postorder_travel(root.rchild)
            # 4.打印根节点的元素域
            print(root.item, end=' ')

# 3.编写测试测试，用于测试对应的功能
# 3.1测试节点和二叉树
def dm01_test():
    # 1.创建节点
    node1 = Node('A')
    # 2.打印该节点的元素域，左右子树
    print(node1.item)  # A
    print(node1.lchild)  # None
    print(node1.rchild)  # None
    print('-' * 23)

    # 3.测试二叉树
    # bt = BinaryTree()
    # print(bt.root)              # None
    bt = BinaryTree(node1)
    print(bt.root)  # 根节点(的地址)
    print(bt.root.item)  # 根节点的元素域

# 3.2模拟队列元素
def dm02_test():
    # 1.创建队列，特点：先进先出
    queue = []
    # 2.模拟往队列中添加元素
    queue.append('A')
    queue.append('B')
    queue.append('C')
    # 3.模拟往队列中取出元素
    print(queue.pop(0))  # A 删除索引，并返回该元素，即：模拟从 队列中获取元素
    print(queue.pop(0))
    print(queue.pop(0))
    # 4.打印队列
    print(queue)


def dm03_breadth_travel_test():
    # 1.创建二叉树对象
    bt = BinaryTree()
    # 2.添加元素
    bt.add('A')
    bt.add('B')
    bt.add('C')
    bt.add('D')
    bt.add('E')
    bt.add('F')
    bt.add('G')
    bt.add('H')
    bt.add('I')
    bt.add('J')
    # 3.广度优先遍历
    bt.breadth_travel()


def dm04_order_travel_test():
    # 1.创建二叉树对象
    bt = BinaryTree()
    # 2.添加节点
    bt.add(0)
    bt.add(1)
    bt.add(2)
    bt.add(3)
    bt.add(4)
    bt.add(5)
    bt.add(6)
    bt.add(7)
    bt.add(8)
    bt.add(9)
    # 3.深度优先遍历。
    print("先序(根左右): ", end=' ')
    bt.preorder_travel(bt.root)
    print("\n中序(左根右): ", end=' ')
    bt.inorder_travel(bt.root)
    print("\n后序(左右根): ", end=' ')
    bt.postorder_travel(bt.root)


# 4.在main函数中具体测试
if __name__ == '__main__':
    # dm01_test()
    # dm02_test()
    # dm03_breadth_travel_test()
    dm04_order_travel_test()



