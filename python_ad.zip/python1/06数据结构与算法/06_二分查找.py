"""
案例：演示二分查找，递归版

二分查找：
    概述：
        属于查找类算法，相对效率比较高，时间复杂度：O(log n)
    前提：
        列表必须有序的
    原理：假设列表是 升序的
        1.比较 要查找的元素 和 列表的中值，如果一样就返回True，恒旭结束
        2.如果 要查找的元素 比 中指小，去前半段(中值前) 查找
        3.如果 要查找的元素 比 中值小，去后半段(中值后) 查找
        4.重复上述步骤，直至找完，如果都找完了，还找不到，就返回False
"""
# 1.定义函数 binary_search_recursion(),表示：二分查找
def binary_search_recursion(my_list,target):
    """
    该函数是 二分查找的递归版，实现查找指定元素
    :param my_list: 待查找的列表
    :param target: 要查找的元素
    :return: True：在 False：不在
    """
    # 1.1获取列表长度
    n = len(my_list)
    # 1.2判断列表是否为空
    if n == 0:
        return False
    # 1.3获取列表的中值(的索引)
    mid = n // 2
    # 1.4比较 要查找的元素和中值
    if my_list[mid] == target:
        return True
    elif target < my_list[mid]:
        # 1.5如果要查找的元素 比 中值小 去前半段(中值前)查找，递归调用
        return binary_search_recursion(my_list[:mid],target)
    elif target > my_list[mid]:
        # 1.6如果要查找的元素 比 中值大，去后半段(中值后)查找，递归调用
        return binary_search_recursion(my_list[mid+1:],target)
    # 走到这里，说明没找到，返回False
    return False

def binary_search(my_list,target):
    # 定义起点和终点
    start = 0
    end = len(my_list) - 1
    # 循环迭代
    while start <= end:
        # 计算中值
        mid = (start + end) // 2
        if my_list[mid] == target:
            return True
        # 如果要查找的元素小于中值，就在前半段继续查找：
        elif target < my_list[mid]:
            end = mid - 1
        # 如果要查找的元素大于中值，就在后半段继续查找：
        else:
            start = mid + 1
    return False

if __name__ == '__main__':
    # 定义列表
    my_list = [1,10,23,32,35,57,64,72,86,92]
    print(binary_search_recursion(my_list, 53))
    print(binary_search_recursion(my_list, 57))
    print(binary_search_recursion(my_list, 23))
    print('-'*23)

    print(binary_search(my_list,53))
    print(binary_search(my_list,57))
    print(binary_search(my_list,23))