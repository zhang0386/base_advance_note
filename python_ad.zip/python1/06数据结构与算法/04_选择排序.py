"""
选择排序：(不稳定)
    原理：
        每轮都假设该轮最前边的那个元素为最小值，然后剩下的元素列表中找到真正的最小值，最终交换即可，本轮就找到了 本轮的最小值，重复即可
    流程：
        假设5个元素
            第几轮(索引)         该轮比较的总次数            公式(具体的谁和谁比较)
               第1轮                4次                    索引0和1，2，3，4比较
               第2轮                3次                    索引1和2，3，4比较
               第3轮                2次                    索引2和3，4比较
               第4轮                1次                    索引3和4比较
    要点：
        1.比较的总轮数        列表长度-1
        2.每轮比较的总次数     i+1 ~ n
        3.谁和谁比较          索引min_index(初值为i) 和 索引j比较，索引i和索引min_index的值交换
    最优时间复杂度：O(n²)
    最坏时间复杂度：O(n²)

    扩展：
        外循环的 -1 ：减少比较的轮数，提高效率
"""
# 升序排列：5 3 4 7 2
def select_sort(my_list):
    n = len(my_list)
    for i in range(n-1):
        min_index = i
        # 内循环
        for j in range(i+1,n):
            if my_list[min_index] > my_list[j]:
                min_index = j
        # 走到这，说明已经找到最小索引
        if min_index != i:
            my_list[min_index], my_list[i] = my_list[i], my_list[min_index]
    print(my_list)

if __name__ == '__main__':
    # l = [5,3,6,7,2]
    l = [2, 3, 5, 7, 6]
    select_sort(l)

