"""
案例：演示 带参数的装饰器

记忆：
    1.1个装饰器的参数有且只能有1个
    2.如果装饰器有多个参数，可以在该装饰器的外边再包裹一层，把该装饰器当作其 内部函数 返回即可
"""
# 需求：定义1个既能装饰减法，又能装饰加法的装饰器 → 即：带有参数的装饰器
# 1.定义装饰器
# 再包裹一层                        # flag:标记
def my_decorator(fn_name):              # 不能直接def my_decorator(fn_name,flag):
    def fn_inner(x,y):
        if fn_name.__name__ == 'get_sum':     # 函数名.__name__可以返回函数名
            print("努力计算[加法]中...")
        elif fn_name.__name__ == 'get_sub':
            print("努力计算[减法]中...")
        return fn_name(x,y)
    return fn_inner

# 2.定义原函数，表示加法运算
@my_decorator
def get_sum(a,b):
    return a + b

# 3.定义原函数，表示减法运算
@my_decorator
def get_sub(a,b):
    return a - b

# 4.测试
if __name__ == '__main__':
    print(get_sum(1,5))
    print(get_sub(9,2))