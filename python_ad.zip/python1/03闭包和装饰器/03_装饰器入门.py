"""
案例：

装饰器介绍；
    概述/作用：
        它的本质是一个闭包函数，目的是 在不改变原有函数的基础上，对其功能进行增强
        大白话：装修队：装修队 在不改变房屋基础的情况下，对房屋做装修（功能增强）
    前提条件：
        1.有嵌套
        2.有引用
        3.有返回
        4。有额外功能
    装饰器的用法：
        格式1：传统写法
            装饰后的函数名 = 装饰器名(被装饰的原函数名)
            装饰后的函数名()
        格式2： 语法糖
            在要被装饰的原函数上，直接写@装饰器名，之后调用函数即可

    细节：
        装饰器的内部函数格式 要和 被装饰的原函数 保持一致
"""
# 定义外部函数
def check_login(fn_name):
    # 定义内部函数
    def fn_inner():
        # 额外功能
        print("校验中...登录成功！")
        # 引用
        fn_name()       # return fn_name() 无参有返
    # 返回
    return fn_inner

def comment():
    print("发表评论")

@check_login            # 相当于payment = check_login(payment)
def payment():
    print("充值中...\n充值成功")

if __name__ == '__main__':
    # 传统写法
    comment = check_login(comment)
    comment()
    # pyment = check_login(payment)
    # pyment()
    print('-'*23)

    # 语法糖
    payment()
