"""
案例：深浅拷贝.

记忆(总结)：
    1.所谓的深浅拷贝分别指的是：
        浅拷贝：copy模块的copy()
        深拷贝：copy模块的deepcopy()函数
    2.大白话：
        深拷贝拷贝得多，浅拷贝拷贝得少
    3.深浅拷贝主要针对可变类型来讲得，深拷贝拷贝所有层(可变)，浅拷贝只拷贝第1层(可变)
        如果是针对不可变类型，用法和 普通赋值一样
"""
# 导包
import copy
# 浅拷贝拷贝可变类型
a = [1,2,3]
b = [11,22,33]
c = [5,6,a,b]

d = copy.copy(c)

print("id(c) → ",id(c))
print("id(d) → ",id(d))
print('-'*23)

a[2] = 66
print("c → ",c)
print("d → ",d)
print('='*34)

# 深拷贝拷贝可变类型
a = [1,2,3]
b = [11,22,33]
c = [5,6,a,b]

d = copy.deepcopy(c)

print("id(c) → ",id(c))
print("id(d) → ",id(d))
print('-'*23)

a[2] = 66
print("c → ",c)
print("d → ",d)