"""
案例：演示多个装饰器装饰1个函数
"""

# 需求：在发表评论前，先校验登录，再验证验证码，加上友好提示
# 1.定义装饰器，表示：校验登录
def check_login(fn_name):
    def fn_inner():
        print("校验中...登录成功！")
        fn_name()
    return fn_inner

# 2.定义装饰器，表示：验证码验证
def verify_captcha(fn_name):
    def fn_inner():
        print("验证码验证通过！")
        fn_name()
    return fn_inner

# 3.原函数
@check_login
@verify_captcha
def comment():
    print("发表成功！")

# 4.测试
if __name__ == '__main__':
    # 语法糖
    comment()
    print('-'*23)

    # 传统写法：由内到外
    comment = verify_captcha(comment)
    comment = check_login(comment)
    comment()