"""
案例：nonlocal关键字介绍

nonlocal：
    它是python内置的关键字，可以实现 在内部函数中 修改外部函数的变量值
"""

# 定义外部函数
def fn_outer():
    # 外部变量
    num = 10
    def fn_inner():
        # 在内部函数中修改外部变量的值
        nonlocal num
        num += 1
        print(f"num:{num}")

    # 返回内部函数名
    return fn_inner

fn_inner =fn_outer()
fn_inner()      # 11
fn_inner()      # 12
fn_inner()      # 13