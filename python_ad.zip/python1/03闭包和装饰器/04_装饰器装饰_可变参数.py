"""
案例：装饰器装饰_有参有返回的原函数

细节：
    装饰器的内部函数格式 要和 被封装的原函数 保持一致，
    即：原函数是无参无返回，则 装饰器的内部函数也必须是 无参无返回的
"""

# 需求：定义1个可以计算多个数据和字典value值和的函数，并给其友好提示
# 1.定义装饰器
def my_decorator(fn_name):
    def fn_inner(*args,**kwargs):
        print("努力计算中...")
        return fn_name(*args,**kwargs)
    return fn_inner


# 2.定义原函数
@my_decorator
def get_sum(*args,**kwargs):
    """
    该函数用于计算 数字列表 和字典value值 之和
    :param args: 数字元组，*args → 接收所有位置参数，封装到 元组
    :param kwargs:字典，键是字符串，值是数字，**kwargs → 接收所有的关键字参数，封装到 字典
    :return:结果之和
    """
    # 定义求和变量
    sum = 0

    # 写法1
    # 遍历元组，求和
    for i in args:
        sum += i
    # 遍历字典，获取每个value求和
    for v in kwargs.values():
        sum += v
    # 打印sum
    # print(f"求和结果:{sum}")
    return sum

    # # 写法2
    # return sum(args) + sum(kwargs.values())

# 测试
if __name__ == '__main__':
    # get_sum(1,2,3,a=5,b=6,c=7)
    sum = get_sum(1,2,3,a=5,b=6,c=7)
    print(f"求和结果:{sum}")
