"""
案例：闭包入门

闭包解释：
    作用：
        保存函数中的变量(外部函数中的变量)
    概述：
        内部函数，使用了外部函数的变量，这种写法就称为闭包
    格式：
        def 外部函数名(形参列表):
            外部函数的(局部)变量

            def 内部函数名(形参列表):
                使用外部函数的变量

            return 内部函数名
    前提条件：
        1.有嵌套           外部函数嵌套内部函数
        2.有引用           内部函数使用外部函数的变量
        3.有返回           外部函数中，返回 内部函数名(对象)
细节：
    1.函数名 和 函数名() 是两个概念，前者表示 函数对象，后者表示 调用函数，获取返回值
"""
def get_sum(a,b):
    return a + b

print(get_sum)      # <function get_sum at 0x000001F06446EEF0>
print(get_sum(1,2))

my_sum = get_sum
print(my_sum)
print(my_sum(11,22))
print('*'*34)

# 案例2.定义一个用于求和的闭包，其中，外部函数有参数num1，内部函数有num2，然后调用，并用于求解；两数之和，观察结果
def external_func(num1):
    # 定义内部函数名
    def internal_func(num2):            # 有嵌套
        sum = num1 + num2               # 有引用
        print(f"两数之和是:{sum}")
    # 返回外部函数
    return internal_func                # 有返回

# 调用函数
internal_func = external_func(10)
internal_func(23)
print(external_func(10))
print(external_func(11))
print('-'*23)

external_func(111)(222)