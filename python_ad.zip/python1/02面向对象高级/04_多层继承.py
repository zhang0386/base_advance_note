"""
案例：演示多层继承

多层继承解释：
    类A继承类B，类B继承类C，这就是多层继承

目前题设中的继承体系
    object ⬅ Master ，School ⬅ Prentice ⬅ TuSun

"""


class Master:
    def __init__(self):
        self.formula = '古法配方'

    def make_cake(self):
        print(f"采用{self.formula}制作煎饼果子")


class School:
    def __init__(self):
        self.formula = '学校独家秘方'

    def make_cake(self):
        print(f"采用{self.formula}制作煎饼果子")


class Prentice(School, Master):  # 就近原则
    def __init__(self):
        self.formula = '独创秘方'

    def make_cake(self):
        print(f"采用{self.formula}制作煎饼果子")

    # 调用父类的功能
    def make_school_cake(self):
        School.__init__(self)
        School.make_cake(self)

    def make_master_cake(self):
        Master.__init__(self)
        Master.make_cake(self)

    # def make_old_cake(self):
    #     super().__init__()  # 不需要写self
    #     super().make_cake()  # 不需要写self

class TuSun(Prentice):
    pass

# 测试
if __name__ == '__main__':
    # 创建徒孙类对象
    ts = TuSun()
    ts.make_cake()
    ts.make_master_cake()
    ts.make_school_cake()



