"""
案例：老师傅有一套精湛的煎饼果子技术，传授给宗门圣子，徒弟还想到煎饼果子学校深造学习，徒弟还开发了一项独家秘方

"""
class Master:
    def __init__(self):
        self.formula = '古法配方'

    def make_cake(self):
        print(f"采用{self.formula}制作煎饼果子")

class School:
    def __init__(self):
        self.formula = '学校独家秘方'

    def make_cake(self):
        print(f"采用{self.formula}制作煎饼果子")

class Prentice(School,Master):  # 就近原则
    def __init__(self):
        self.formula = '独创秘方'

    def make_cake(self):
        print(f"采用{self.formula}制作煎饼果子")

p = Prentice()
print(p.formula)
p.make_cake()
print('-'*34)

print(Prentice.mro())  # Prentice → School → Master → object
print(Prentice.__mro__)  # Prentice → School → Master → object
