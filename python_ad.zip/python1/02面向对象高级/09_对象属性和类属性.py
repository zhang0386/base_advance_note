"""
案例：演示对象属性和类属性

属性介绍：
    概述：
        它是一个名词用来描述外部特征
    分类：
        对象属性：属于每个对象，即：每个对象的属性值可能都不同，修改A对象的属性，不影响其他属性
        类属性：属于类的，即：能被该类下的对象所共享，A对象修改类属性，B对象访问的是修改后的

对象属性：
    定义到init 魔法方法中的属性，每个对象都有自己的内容
    只能通过对象名.的方式调用

类属性：
    定义到类中，函数外的属性(变量)，能被该类下的所有对象使用
    既能通过 类名. 还能通过 对象名. 的方式来调用，推荐使用类名，的方式
"""
# 1.定义学生类
class Student:
    # 2.定义类属性
    teacher_name = 'HlXt'
    # 3.定义对象属性
    def __init__(self,name,age):
        self.name = name
        self.age = age

    # 4.定义str，输出对象信息
    def __str__(self):
        return '姓名: %s,年龄: %d' % (self.name , self.age)

# 5.测试
if __name__ == '__main__':
    s1 = Student('大王',20)
    s2 = Student('小王',19)

    # 修改s1的属性
    s1.name = '强者'
    s1.age = 21

    print(f"s1:{s1}")
    print(f"s2:{s2}")
    print('-'*34)

    print(s1.teacher_name)
    print(s2.teacher_name)
    print(Student.teacher_name)
    print('*'*34)

    # 尝试修改teacher_name只能通过 类名.类属性 改变
    Student.teacher_name = '王炸'
    print(s1.teacher_name)
    print(s2.teacher_name)
    print(Student.teacher_name)
