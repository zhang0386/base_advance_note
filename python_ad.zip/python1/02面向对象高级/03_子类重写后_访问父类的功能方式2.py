"""
案例：子类重写父类功能后，继续访问父类功能

思路：
    1.父类名.父类函数名(self)   精准访问，想找哪个父类，就调用哪个父类
    2.super().父类函数名()     只能访问最近的那个父类，有就用，没有就往后查找

"""
class Master:
    def __init__(self):
        self.formula = '古法配方'

    def make_cake(self):
        print(f"采用{self.formula}制作煎饼果子")

class School:
    def __init__(self):
        self.formula = '学校独家秘方'

    def make_cake(self):
        print(f"采用{self.formula}制作煎饼果子")

class Prentice(School,Master):  # 就近原则
    def __init__(self):
        self.formula = '独创秘方'

    def make_cake(self):
        print(f"采用{self.formula}制作煎饼果子")

    # 调用父类的功能
    # def make_school_cake(self):
    #     School.__init__(self)
    #     School.make_cake(self)
    # 
    # def make_master_cake(self):
    #     Master.__init__(self)
    #     Master.make_cake(self)
    
    def make_old_cake(self):
        super().__init__()      # 不需要写self
        super().make_cake()     # 不需要写self

# 测试
if __name__ == '__main__':
    p = Prentice()
    print(p.formula)
    p.make_cake()
    print('-'*34)
    # p.make_school_cake()
    # p.make_cake()   #p.make()函数被重置了
    # print('-'*34)
    # p.make_master_cake()
    # p.make_cake()   #p.make()函数被再次重置了
    p.make_old_cake()



