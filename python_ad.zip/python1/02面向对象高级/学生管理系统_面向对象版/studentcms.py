"""
该文件用于 完成学生管理系统的 具体业务，即：增删改查，保存学生信息等
"""
# 导包
from student import Student
import time

# 创建学生管理系统类
class StudentCMS(object):
    # 通过init魔法方法，初始化属性信息
    def __init__(self):
        # # 创建一个空列表，用于储存学生信息
        self.stu_list = []
        # 定义一个列表，方便测试
        # self.stu_list = [
        #     Student('大王','男','21','111','爱吃鱼'),
        #     Student('小王','男','20','222','不爱吃鱼'),
        #     Student('卷帘','男','88','333','谁动里我的大酱'),
        #     Student('王炸','男','10','555','要不起'),
        #     Student('连对','男','8','666','这么爱出连对是吧'),
        # ]

    # 定义函数，实现打印，管理系统的界面
    def show_view(self):
        print('*'*34)
        print("本学员管理系统V2.0可完成如下操作:")
        print("\t1.添加学员")
        print("\t2.删除学员")
        print("\t3.修改学员")
        print("\t4.查询某个学员")
        print("\t5.显示所有学员")
        print("\t6.保存信息")
        print("\t0.退出系统")
        print('*'*34)
        print()

    # 1.定义函数，实现添加学员信息
    def add_student(self):
        name = input("请输入姓名:")
        gender = input("请输入性别:")
        age = input("请输入你的年龄:")
        phone = input("请输入你的联系电话:")
        desc = input("请输入你的描述信息:")
        stu = Student(name,gender,age,phone,desc)
        self.stu_list.append(stu)
        print(f"添加{name}学生信息成功！\n")

    # 2.定义函数，实现删除学员信息
    def del_student(self):
        self.search_all_student()
        del_name = input("请输入你要删除信息的学员:")
        for stu in self.stu_list:
            if stu.name == del_name:
                print(stu)
                answer = input("确定要删除该学员对象信息吗？ (Y/N) →")
                print()
                if answer.lower() == 'y':
                    self.stu_list.remove(stu)
                    print(f"删除{del_name}学员信息成功！\n")
                break
        else:
            print("输入有误，暂无该学员信息，请重新输入\n")


    # 3.定义函数，实现修改学员信息
    def update_student(self):
        self.search_all_student()
        upd_name = input("请输入你要修改信息的学员:")
        for stu in self.stu_list:
            if stu.name == upd_name:
                stu.name = input("输入你要修改的名字:")
                stu.gender = input("输入你要修改的性别:")
                stu.age = input("请输入你要修改的年龄:")
                stu.phone = input("请输入你要修改的联系电话:")
                stu.desc = input("请输入你要修改的描述信息:")
                print(f"修改{upd_name}学员信息成功！\n")
                break
        else:
            print("输入有误，请重新操作\n")

    # 4.定义函数，实现查询单个学员信息
    def search_one_student(self):
        search_name = input("请输入你要查询信息的学员:")
        for stu in self.stu_list:
            if stu.name == search_name:
                print(stu,end='\n\n')
                break
        else:
            print("输入有误，暂无该学员信息，请重新输入\n")

    # 5.定义函数，实现显示所有学员信息
    def search_all_student(self):
        # 1.判断学生列表stu_list,长度是否为0，0的话则，输出：暂无学生信息，请录入后再查看
        if len(self.stu_list) == 0:
            print("暂无学生信息，请录入后再查看！\n")
        # 2.不为0，则：遍历所有学生信息
        else:
            for stu in self.stu_list:
                print(stu)
            print()

    # 6.定义函数，实现保存所有学员信息
    def save_student(self):
        # 关联学生信息文件
        with open("./stu_data.txt",'w',encoding='utf-8') as dest_f:
            # 将学生对象转成字典
            stu_dict = [stu.__dict__ for stu in self.stu_list]
            # 把字典持久化到文件中
            dest_f.write(str(stu_dict))     # 记得转成str

    # 7.定义函数，实现加载学员信息功能
    def load_student(self):
        # 加入异常处理
        try:
            # 关联学生信息文件
            with open('./stu_data.txt','r',encoding='utf-8') as src_f:
                # 一次性读取所有数据
                stu_data = src_f.read()         # '[字典,字典,字典]'
                # 把上述的字符串转为列表
                stu_list = eval(stu_data)       # ‘’
                # 如果列表为空，赋予空列表
                if len(stu_list) == 0:
                    stu_list = 0
                # 把stu_list(列表套字典) 转成 [学生对象，学生对象...] 并赋值给self.stu_list
                self.stu_list = [Student(**stu_dict) for stu_dict in stu_list]
        except:
            # 走到这里说明文件不存在
            with open('./stu_data.txt', 'w', encoding='utf-8') as src_f:
                pass


    # 8.定义函数，实现上述所有业务功能跑通
    def start(self):
        # 加载学生信息
        self.load_student()
        while True:
            # 为了效果更明显，加入：延迟(休眠线程)
            time.sleep(1)
            # 打印学生系统界面
            self.show_view()
            input_num = input("请输入你要操作的编号:")
            if input_num == '1':
                print('-'*10,"添加学员信息",'-'*10,"\n")
                self.add_student()
            elif input_num == '2':
                print('-'*10,"删除学员信息",'-'*10,"\n")
                self.del_student()
            elif input_num == '3':
                print('-'*10,"修改学员信息",'-'*10,"\n")
                self.update_student()
            elif input_num == '4':
                print('-'*10,"查询单个学员信息",'-'*10,"\n")
                self.search_one_student()
            elif input_num == '5':
                print('-'*10,"查询全部学员信息",'-'*10,"\n")
                self.search_all_student()
            elif input_num == '6':
                print('-'*10,"保存学员信息",'-'*10,"\n")
                self.save_student()
                print("学员信息保存成功！\n")
            elif input_num == '0':
                result = input("你确定要退出吗? (Y/N) → ")
                if result.lower() == 'y':       # 字符串.lower() 将字符串转成小写
                    # 退出前自动保存信息
                    self.save_student()
                    print("谢谢使用,期待下次再会")
                    break
            else:
                print("输入错误，请重新输入！")




if __name__ == '__main__':
    cms = StudentCMS()
    cms.start()

    # # 查看当前文件路径
    # import os
    # print(os.getcwd())