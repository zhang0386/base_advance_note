"""
该文件用于记录学生类，学生的属性信息为：姓名，性别，年龄，联系方式，描述信息.
"""

# 定义学生类
class Student:
    def __init__(self,name,gender,age,phone,desc):
        """
        该魔法方法，用于初始化学生属性
        :param name: 姓名
        :param gender: 性别
        :param age: 年龄
        :param phone: 联系方式
        :param desc: 描述
        """
        self.name = name
        self.gender = gender
        self.age = age
        self.phone = phone
        self.desc = desc

    def __str__(self):
        """
        该魔法方法，用于打印学生信息
        :return:
        """
        return (f"姓名:{self.name},性别:{self.gender},"
                f"年龄:{self.age},联系方式:{self.phone},"
                f"描述信息:{self.desc}")

# 测试
if __name__ == '__main__':
    s = Student('小明','男',21,'12312345678','喜欢爬树')
    print(s)