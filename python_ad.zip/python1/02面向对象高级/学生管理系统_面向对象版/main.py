"""
该文件 用作学生管理系统的入口文件
"""
# 导包
from studentcms import StudentCMS

# 程序的主入口
if __name__ == '__main__':
    stu_cms = StudentCMS()
    stu_cms.start()

