"""
案例：演示多态入门

多态概述：
    专业版：同一个函数，接收不同的参数，有不同的效果
    大白话：同一个事物在不同时刻表现的不同状态，形态

    前提条件：
        1.要有继承
        2.要有方法重写，不然多态无意义
        3.要有父类引用指向子类对象
    案例：
        动物园案例
"""
from inspect import classify_class_attrs


# 定义动物类
class Animal:
    pass

# 定义汽车类
class Car:
    def sound(self):
        print("嘀嘀嘀")

# 定义子类，dog类
class Dog(Animal):
    def sound(self):
        print("狗叫:汪汪汪")

# 定义子类，cat类
class Cat(Animal):
    def sound(self):
        print("猫叫:喵喵喵")

# 定义函数，接收不同对象，调用函数
def make_noise(an:Animal):
    an.sound()

if __name__ == '__main__':
    an:Animal = Dog()    # 父类引用指向子类对象
    o:Dog = Dog()        # 创建子类对象

    d = Dog()
    c = Cat()
    ca = Car()

    make_noise(d)
    make_noise(c)
    make_noise(ca)