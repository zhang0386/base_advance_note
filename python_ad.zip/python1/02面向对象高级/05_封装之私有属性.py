"""
案例: 演示封装之私有属性

封装简介:
    概述:
        属于面向对象的三大特征之一，就是隐藏对象的属性和实现细节，仅对外提供公共的访问方式
    私有属性格式:
        __属性
    特点:
        私有属性不能直接访问，在python中，一般定义方法名为
        ‘get_xx’用来获取私有属性,定义‘set_xx’用来修改私有属性
    需求: 小明想将技术传给徒孙，但不想也把私房钱传给他
"""

# 定义师傅类

# 定义学校类

# 定义学徒类
class Prentice:
    def __init__(self):
        self.formula = '独创秘方'
        self.__money = 5000000

    def make_cake(self):
        print(f"用{self.formula}制作煎饼果子")

    # 针对私有属性，提供对外界的公共方式
    def get_money(self):
        return self.__money

    # 如果想类外改变类内的属性，则必须:
    def set_money(self,money):
        self.__money = money

# 定义徒孙类
class TuSun(Prentice):
    pass

# 测试
if __name__ == '__main__':
    ts = TuSun()
    print(ts.formula)
    ts.make_cake()
    print('-'*34)
    # print(ts.__money)   # 徒孙访问不到学徒的私有属性
    ts.__money = 100    # 类外定义不能改变类内的属性
    print(ts.get_money())   # 通过父类提供的公共访问方式，访问父类的私有成员
    print('='*34)
    ts.set_money(200000)
    print(ts.get_money())
