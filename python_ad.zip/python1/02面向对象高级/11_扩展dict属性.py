"""
案例：演示Python内置dict属性

__dict__属性介绍：
    可以把对象转成字典形式
"""
from 学生管理系统_面向对象版.student import Student

# 需求1:把 学生对象 → 字典形式，属性名做键，属性值做值
s1 = Student('王炸','男','10','555','要不起')
print(s1)

s1_dict = s1.__dict__
print(s1_dict)
print(type(s1_dict))
print('-'*34)

# 需求2：把所有学生对象 → 字典
s2 = Student('大王','男','21','111','爱吃鱼')
s3 = Student('小王','男','20','222','不爱吃鱼')
s4 = Student('卷帘','男','88','333','谁动里我的大酱')
stu_list = [s2,s3,s4]

# 列表推导式
stu_dict = [stu.__dict__ for stu in stu_list]
print(stu_dict)
print('-'*34)

# 需求3：把 字典形式 → 学生对象
my_dict = {'name': '王炸', 'gender': '男', 'age': '10', 'phone': '555', 'desc': '要不起'}
s5 = Student(my_dict['name'],my_dict['gender'],my_dict['age'],my_dict['phone'],my_dict['desc'])
print(s5)
print(type(s5))

# 高级写法：输出同上
s6 = Student(**my_dict)
print(s6)
print(type(s6))