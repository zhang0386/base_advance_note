"""
案例：演示抽象类的用法

抽象类的解释：
    概述：
        在python中，抽象类 = 接口，即： 有抽象方法的类就是抽象类，也叫接口。
        抽象方法 = 没有方法体的方法，即： 方法体是pass修饰的
    作用/目的：
        抽象类一般充当父类，用于指定行业规范，准则，具体的实现由子类完成
"""

# 定义空调抽象类(规则)
class AC:
    # 制冷
    def cool_wind(self):
        pass
    # 制热
    def hot_wind(self):
        pass
    # 左右摆风
    def swing_l_r(self):
        pass

# 定义子类(美的空调)
class Midea(AC):
    # 制冷
    def cool_wind(self):
        print("美的 核心空调制冷技术")

    # 制热
    def hot_wind(self):
        print("美的 核心空调制热技术")

    # 左右摆风
    def swing_l_r(self):
        print("美的 核心空调低频摆动技术")

# 定义子类(小米空调)
class XiaoMi(AC):
    # 制冷
    def cool_wind(self):
        print("小米 核心空调制冷技术")

    # 制热
    def hot_wind(self):
        print("小米 核心空调制热技术")

    # 左右摆风
    def swing_l_r(self):
        print("小米 核心空调静音摆动技术")

if __name__ == '__main__':
    midea = Midea()
    xiaomi = XiaoMi()

    midea.cool_wind()
    midea.hot_wind()
    midea.swing_l_r()
    print('*'*34)
    xiaomi.cool_wind()
    xiaomi.hot_wind()
    xiaomi.swing_l_r()