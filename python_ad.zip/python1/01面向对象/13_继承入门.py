"""
继承：
    子类继承父类的属性和行为
"""
class Father(object):
    def __init__(self):
        self.gender = 'man'

    def work(self):
        print("一份高新工作")

    def mood(self):
        print("好心情")

class Son(Father):
    pass

c1 = Son()
print(c1.gender)
c1.work()
c1.mood()
