"""
案例：在类外，通过关键字self，访问其他函数
谁调用了函数，self就指向谁
"""

class Car:
    def run(self):
        print("go!")
        print(f"我是run函数，self的值是:{self}")

# 创建对象
c1 = Car()
print(f"c1对象:{c1}")
print(f"c1对象的地址值:{id(c1)}")
# 通过对象.方法 ，调用Car#run()
c1.run()
print('-'*34)

# 创建对象2
c2 = Car()
print(f"c1对象:{c2}")
print(f"c1对象的地址值:{id(c2)}")
# 通过对象.方法 ，调用Car#run()
c2.run()
