"""
案例：在类内，通过关键字self，访问其他函数
self：
# 代表本类对象的引用，谁调用了函数，self就指向谁
"""

# 定义汽车类，类中有run(),work()中有run(),创建该对象，调用上述函数
class Car:
    def run(self):
        print("go!")

    def work(self):
        print("我是work")
        self.run()



# 创建对象
c1 = Car()

# 调用Car#work
c1.work()