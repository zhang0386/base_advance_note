"""
案例：老师傅有一套精湛的煎饼果子技术，传授给宗门圣子，徒弟还想到煎饼果子学校深造学习

扩展：MRO机制(Method Resolution Order)
    解释：
        在python中有MRO机制，可以查看某个对象，在调用时的顺序，即：先找哪个类，后找哪个类
    格式：
        类名.mro()
        类名.__mro__
"""
class Master:
    def __init__(self):
        self.formula = '古法配方'

    def make_cake(self):
        print(f"采用{self.formula}制作煎饼果子")

class School:
    def __init__(self):
        self.formula = '学校独家秘方'

    def make_cake(self):
        print(f"采用{self.formula}制作煎饼果子")

class Prentice(School,Master):  # 就近原则
    pass

p = Prentice()
print(p.formula)
p.make_cake()
print('-'*34)

print(Prentice.mro())  # Prentice → School → Master → object
print(Prentice.__mro__)  # Prentice → School → Master → object
