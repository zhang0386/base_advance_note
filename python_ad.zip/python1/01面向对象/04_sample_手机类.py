"""
案例：定义手机类，能开机、关机、拍照
"""

class Phone:
    def Open(self):
        print("开机中...")

    def Off(self):
        print("正在关机...")

    def Photo(self):
        self.Open()
        print("准备拍照中...")

# 创建对象
c1 = Phone()

# 调用函数
c1.Open()
print('-'*34)
c1.Photo()
print('='*34)
c1.Off()

