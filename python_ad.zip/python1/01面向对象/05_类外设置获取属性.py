"""

"""
# 定义汽车类，类中有run(),work()中有run(),创建该对象，调用上述函数
class Car:
    def run(self):
        print("go!")

    def work(self):
        print("我是work")
        self.run()



# 创建对象
c1 = Car()
c1.color = "blue"
c1.number = 4
print(f"汽车颜色：{c1.color},汽车轮子数：{c1.number}")
# 调用Car#work
c1.work()

# # 创建对象2
# c2 = Car()
# print(f"汽车颜色：{c2.color},汽车轮子数：{c2.number}")
# # 调用Car#work
# c2.work()

