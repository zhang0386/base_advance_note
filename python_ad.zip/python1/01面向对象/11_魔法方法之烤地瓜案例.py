"""
案例需求：
    1. 定义地瓜类 → SweetPotato
    2. 属性：焙烤时间cook_time,焙烤状态cook_state,调料condiments
    3. 行为：焙烤cook(),添加调料add_condiments()
    4. 魔法方法：init() → 初始化属性，str() → 打印地瓜信息.
    5. 规则:
        焙烤时间        地瓜状态
        [0, 3)          生的
        [3, 7)         半生不熟
        [7, 12)         熟了
        [12, ∞)         糊了
"""

class SweetPotato:
    def __init__(self,cook_time):
        self.cook_time = cook_time
        self.cook_state = '生的'
        self.condiments = []

    def __str__(self):
        return f"地瓜当前状态:{self.cook_state},总焙烤时间:{self.cook_time},调料:{self.condiments}"

    def cook(self):
        if 0 <= self.cook_time < 3:
            self.cook_state = "生的"
        elif  3 <= self.cook_time < 7:
            self.cook_state = "半生不熟"
        elif  7 <= self.cook_time < 12:
            self.cook_state = "熟了"
        else:
            self.cook_state = "糊了"


    def add_condiments(self):
        while True:
            condiments = input("请添加你想要的调料:")
            self.condiments.append(condiments)
            while True:
                answer = input("是否继续添加调料y/n:")
                if answer == 'y':
                    break   # 跳出内层循环
                elif answer == 'n':
                    return  # 直接结束整个方法
                else:
                    print("无效输入，请输入y/n")

def main():
    cook_time = int(input("请输入焙烤时间(minute):"))
    if cook_time <= 0:
        print("无效输入,请重新运行程序")
        return  # 直接结束main
    sp = SweetPotato(cook_time)
    sp.cook()
    print(sp)
    sp.add_condiments()
    print("最终状态:",sp)

if __name__ == '__main__':
    main()
