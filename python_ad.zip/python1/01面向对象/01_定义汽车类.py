"""
案例：定义汽车类，有跑的行为

定义类的格式
class 类名(self)：    # self是内置关键字，指向对象实例本身
   # 属性
   # 行为

"""
class Car:
    def run(self):
        print("car run!")

# 创建该类的对象
car = Car()
# 调用Car#run,对象.方法
car.run()