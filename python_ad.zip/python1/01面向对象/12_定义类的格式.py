"""
定义类的格式：
    格式1：
        class 类名:

    格式2：
        class 类名():

    格式3：
        class 类名(object):
"""

# class Teacher:
# class Teacher():
class Teacher(object):
    pass
