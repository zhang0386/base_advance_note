"""
案例：演示str魔法方法的用法

魔法方法：
    概述/特点：
        python内置函数，在满足特定的场景下，会被自动调用
    常用的魔法方法：
        __init__()    在每次创建对象的时候，会自动触发该类的__init__()函数
        __str__()     当用print()函数打印对象的时候，会自动调用该对象(所在类)的str魔法方法
        __del__()     当.py文件执行结束，或者手动del释放该对象资源，会自动调用该函数.
"""

class Car:
    def __init__(self,color,number):
        """
        该魔法方法用于给汽车类对象的属性赋值
        :param color: 汽车的颜色
        :param number: 汽车的轮胎数
        """
        print("我是init函数")
        self.color = color
        self.number = number

    def show(self):
        print(f"颜色：{self.color},数量：{self.number}")

# 创建对象,调用函数
c1 = Car('red',4)
c1.show()
print('='*34)

c2 = Car('blue','10')
c2.show()