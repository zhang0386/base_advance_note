"""
案例：小明同学当前体重是100kg。每当他跑步一次时，则减少0.5kg，他大吃大喝一次时，则会增加2kg。
"""


class Student:
    def __init__(self):
        name = input("请输入名字:")
        current_weight = int(input("请输入当前体重(kg):"))
        self.name = name
        self.current_weight = current_weight

    def __str__(self):
        return f"{self.name}同学当前体重是:{self.current_weight}kg"

    def __del__(self):
        print(f"{self.name}对象已释放,请重新运行程序建立对象")

    def run(self):
        num = int(input("请输入跑步次数:"))
        for i in range(num):
            self.current_weight -= 0.5

    def eat(self):
        count = int(input("请输入大吃大喝次数:"))
        for i in range(count):
            self.current_weight += 2

def main():
    obj_list = []
    choose = 'y'
    while choose == 'y':
        st = Student()
        obj_list.append(st)
        st.run()
        st.eat()
        print(st)
        choose = input("是否继续执行y/n:")

if __name__ == '__main__':
    main()