"""
案例：老师傅有一套精湛的煎饼果子技术，传授给宗门圣子
"""

class Master:
    def __init__(self):
        self.formula = '古法配方'

    def make_cake(self):
        print(f"采用{self.formula}制作煎饼果子")

class Prentice(Master):
    pass

p = Prentice()
p.make_cake()