"""
案例：演示str魔法方法的用法

魔法方法：
    概述/特点：
        python内置函数，在满足特定的场景下，会被自动调用
    常用的魔法方法：
        __init__()    在每次创建对象的时候，会自动触发该类的__init__()函数
        __str__()     当用print()函数打印对象的时候，会自动调用该对象(所在类)的str魔法方法
        __del__()     当.py文件执行结束，或者手动del释放该对象资源，会自动调用该函数.
"""

class Car:
    def __init__(self,brand):
        self.brand = brand

    def __str__(self):
        return f"汽车品牌:{self.brand}"

    def __del__(self):
        print(f"{self.brand}汽车对象被销毁了")

c1 = Car('BMW')
print(c1)
# del c1
print('-'*34)

del c1
# print(c1.brand)

print("程序执行完毕")