"""
案例：定义两个目标函数，对全局变量进行累加100w次，观察结果

多线程共享全局变量，出现问题：
    累加次数不够
产生原因：
    线程1没执行完，线程2抢占资源
解决方案：
    互斥锁

进程和线程的区别：
    1.线程依赖进程，进程是CPU分配资源的基本单位，线程是CPU调度资源的基本单位
    2.进程更消耗资源，不能共享全局变量，相对更稳定
    3.线程更轻量级，可以共享全局变量，相对更灵活
"""
# 导包
import threading
import time

# 定义全局变量
global_num = 0

# 定义锁
mutex = threading.Lock()

# 定义目标函数1
def target_fun1():
    mutex.acquire()         # 加锁
    # 声明为全局变量
    global global_num
    # 遍历
    for i in range(1000000):
        # 累加
        global_num += 1
        time.sleep(0)
    # 打印结果
    print(f"target_fun1函数的结果是：{global_num}")
    mutex.release()         # 释放锁

# 定义目标函数2
def target_fun2():
    mutex.acquire()
    # 声明为全局变量
    global global_num
    # 遍历
    for i in range(1000000):
        # 累加
        global_num += 1
        time.sleep(0)
    # 打印结果
    print(f"target_fun2函数的结果是：{global_num}")
    mutex.release()

# 测试
if __name__ == '__main__':
    # 创建子线程
    t1 = threading.Thread(target=target_fun1)
    t2 = threading.Thread(target=target_fun2)

    # 启动线程
    t1.start()
    t2.start()




