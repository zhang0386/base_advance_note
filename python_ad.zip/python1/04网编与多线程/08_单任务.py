"""
演示：单任务进程
"""
def fun_a():
    for i in range(12):
        print("hello")

def fun_b():
    for i in range(10):
        print("world!")

if __name__ == '__main__':
    fun_a()
    print('-'*23)
    fun_b()