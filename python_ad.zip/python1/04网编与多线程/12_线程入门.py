"""
案例：线程入门案例

需求：实现一边写代码，一边听音乐
"""
# 导包
import threading
import time

def coding(name,num):
    for i in range(1,num):
        time.sleep(0.1)
        print(f"{name}正在写第{i}行代码...")


def music(name,count):
    for i in range(1,count):
        time.sleep(0.1)
        print(f"{name}正在听第{i}首音乐")

if __name__ == '__main__':
    t1 = threading.Thread(target=coding,name="第一线程",args=('小冬瓜',11))
    t2 = threading.Thread(target=music,name="第二线程",kwargs={'name':'小南瓜','count':11})

    # 启动线程
    t1.start()
    t2.start()

