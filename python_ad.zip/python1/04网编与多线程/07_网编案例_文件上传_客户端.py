"""
案例：文件上传(客户端)

回顾：客户端开发流程：
    1.创建客户端Socket对象
    2.连接服务器端的 ip 和 端口号
    3.关联数据源文件，读取内容发送给服务器端
    4.接收回执信息
    5.释放资源
"""
# 导包
import socket

# 1.创建客户端Socket对象
client_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
# 2.连接服务器端的 ip 和 端口号
client_socket.connect(('127.0.0.1',2323))
# 3.关联数据源文件，读取内容发送给服务器端
# 3.1关联数据源数据
with open(r"D:\wallpaper\【哲风壁纸】云彩-夜晚-夜景.png",'rb') as src_f:
    # 3.2循环读取内容
    while True:
        # 3.3读取具体内容
        data = src_f.read(8192)
        # 3.3把读取到的数据写给服务器端
        client_socket.send(data)
        # 3.4如果读取到的数据为空，说明文件读取完毕
        if len(data) == 0:
            break
# 发送完成关闭写端
client_socket.shutdown(socket.SHUT_WR)
# 4.接收回执信息
res = client_socket.recv(1024).decode('utf-8')
print(res)
# 5.释放资源
client_socket.close()