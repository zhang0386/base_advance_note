"""
案例：演示多进程特点 之 守护多线程

多线程特点：
    1.线程执行的随机性，原因是CPU在做高效切换
    2.默认情况下，主线程会等待子线程结束再结束
    3.(同一个进程的)线程间数据共享
    4.多线程操作共享数据，可能会出现安全问题，可以用 互斥锁解决
"""
# 导包
import threading,time

# 定义目标函数
def work():
    for i in range(10):
        time.sleep(0.2)
        print('工作中...')

# 测试
if __name__ == '__main__':
    # 创建子线程对象
    # # (守护线程)写法1：daemon属性
    # t = threading.Thread(target=work,daemon=True)

    # # (守护线程)写法2：setDaemon()函数，已过时
    # t = threading.Thread(target=work)
    # t.setDaemon(True)

    # # (守护线程)写法3：daemon属性
    t = threading.Thread(target=work)
    t.daemon = True


    # 启动线程
    t.start()

    # 设置主线程延迟1秒
    time.sleep(1)
    # 设置主线程结束标志
    print("主线程结束!")