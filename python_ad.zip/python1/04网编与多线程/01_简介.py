"""
网编(socket)：用来实现 不同计算机上 运行的程序间 进行数据交互 IP，端口号，协议
进程，线程都是程序(CPU)实现多任务的手段

进程(processing)：CPU分配资源的最小单位
线程(threading)：CPU调度资源的最小单位

进程间数据隔离，线程间数据共享
"""
# count = 0
# for s in [str(i) for i in range(1234,4322)]:
#     if '1' in s and '2' in s and '3' in s and '4' in s and '13' not in s and '31' not in s and s[0] != '4':
#         count += 1
#         print(s,end='\n' if count % 5 == 0 else '\t')
