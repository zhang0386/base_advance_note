"""
案例：演示获取进程的编号

进程编号解释：
    概述：每个程序(进程)都有自己的唯一进程id，当程序释放的时候，在进程id也会释放，即：进程id是可以重复使用的
    目的：
        1.查看子进程和父进程的关系，方便 管理
        2.例如：杀死指定进程，创建子进程
    格式：
        查看当前进程的pid：
            os模块(operating，系统模块)的getpid()       get Process id
            multiprocessing#current_process()的pid属性

            查看当前进程的pid：     parent process id(父进程)
                os#getpid()
细节：
    main进程的父进程是PyCharm程序的pid
"""
# 导包
import multiprocessing
import os
import time

def coding(name,num):
    for i in range(1,num):
        time.sleep(0.1)
        print(f"{name}正在敲第{i}行代码...")
    print(f"p1的进程pid是:{os.getpid()},{multiprocessing.current_process().pid},父进程id(ppid)为:{os.getppid()}")
def music(name,count):
    for i in range(1,count):
        time.sleep(0.1)
        print(f"{name}正在听{count}首音乐......")
    print(f"p2的进程pid是:{os.getpid()},{multiprocessing.current_process().pid},父进程id(ppid)为:{os.getppid()}")

if __name__ == '__main__':
    # 查看main进程的pid和ppid
    print(f"main的进程pid是:{os.getpid()},{multiprocessing.current_process().pid},父进程id(ppid)为:{os.getppid()}")
    time.sleep(10)

    # 创建子进程
    p1 = multiprocessing.Process(target=coding,args=('小明',11))
    p2 = multiprocessing.Process(target=music,kwargs={'name':'小南瓜','count':11})

    # 启动进程
    p1.start()
    p2.start()

