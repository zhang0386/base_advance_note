"""
演示：多进程

多进程目的：
    它属于多任务的一种实现方式，目的是充分利用CPU资源，提高程序执行效率

实现方式：
    1.导包
    2.创建进程对象，关联目标函数
    3.启动进程
"""

# 导包
import multiprocessing
import time

def coding():
    for i in range(1,10):
        time.sleep(0.1)
        print(f"正在敲第{i}行代码！")

def music():
    for i in range(1,10):
        time.sleep(0.1)
        print(f"正在听第{i}首音乐......")

if __name__ == '__main__':
    # 在主进程里面创建子进程对象
    p1 = multiprocessing.Process(target=coding)
    p2 = multiprocessing.Process(target=music)

    # 启动进程
    p1.start()
    p2.start()