"""
案例：演示带参数的多进程

进程传参的两种方式：
    方式1：args方式，接收所有的 位置参数
    方式2：kwargs方式，接收所有的 关键字参数
"""
# 导包
import multiprocessing
import time

def coding(name,num):
    for i in range(1,num):
        time.sleep(0.1)
        print(f"{name}正在敲第{i}行代码...")

def music(name,count):
    for i in range(1,count):
        time.sleep(0.1)
        print(f"{name}正在听{count}首音乐......")

if __name__ == '__main__':
    # 创建子进程
    p1 = multiprocessing.Process(target=coding,args=('小明',11))
    p2 = multiprocessing.Process(target=music,kwargs={'name':'小南瓜','count':11})

    # 启动进程
    p1.start()
    p2.start()