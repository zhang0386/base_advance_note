"""
案例：演示编解码

细节：
    1.编码
        '字符串'.encode(码表)
    2.解码
        二进制.decode(码表)
    3.英文字母，数字，特殊符号，无论什么码表都只占1个字节，中文在gpk占2个字节，utf-8中占3个字节
"""
s1 = '强者无敌123@qq。'
print(s1.encode())              # b'\xe5\xbc\xba\xe8\x80\x85\xe6\x97\xa0\xe6\x95\x8c123@qq\xe3\x80\x82'
print(s1.encode('utf-8'))       # b'\xe5\xbc\xba\xe8\x80\x85\xe6\x97\xa0\xe6\x95\x8c123@qq\xe3\x80\x82'
print(s1.encode('gbk'))         # b'\xc7\xbf\xd5\xdf\xce\xde\xb5\xd0123@qq\xa1\xa3'
print('-'*23)

bys = b'\xe5\xbc\xba\xe8\x80\x85\xe6\x97\xa0\xe6\x95\x8c123@qq\xe3\x80\x82'
bys1 = b'\xc7\xbf\xd5\xdf\xce\xde\xb5\xd0123@qq\xa1\xa3'
print(type(bys))
print(bys.decode())
print(bys.decode('utf-8'))


print(bys.decode('gbk',errors="ignore"))
print(bys1.decode('utf-8',errors="ignore"))

