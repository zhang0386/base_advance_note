"""
案例：网编入门案例，服务器端给客户端发送信息，客户端给出回执信息

服务器端开发流程：
    1.创建服务器端Socket对象
    2.连接服务器端，指定：服务器端IP，端口号
    3.接收服务器端的信息并打印
    4.给服务器端发送信息
    5.释放资源
"""
# 导包
import socket

# 1.创建服务器端Socket对象.ipv4,TCP协议
client_socket = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
# 2.连接服务器端，指定：服务器端IP，端口号
client_socket.connect(('127.0.0.1',10086))
print("[客户端]已连接到服务器")
# 3.接收服务器端的信息并打印
data = client_socket.recv(1024).decode('utf-8')
print(f"[客户端]接收到服务器端信息：{data}")
# 4.给服务器端发送信息
client_socket.send('今天星期几'.encode('utf-8'))
print("[客户端]消息已发送")
# 5.释放资源
client_socket.close()

