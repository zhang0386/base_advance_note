
import pygame
import random
import math
import sys
import os
from dataclasses import dataclass
from typing import List

# 初始化 pygame
pygame.init()

# 屏幕设置
SCREEN_WIDTH = 900
SCREEN_HEIGHT = 700
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("生理期关怀小助手")

# 颜色主题 - 柔和暖色调
COLORS = {
    'bg_top': (255, 245, 250),
    'bg_bottom': (255, 235, 240),
    'bubble_do': (255, 192, 203),
    'bubble_dont': (255, 160, 170),
    'bubble_do_border': (255, 105, 180),
    'bubble_dont_border': (220, 100, 120),
    'text_dark': (80, 40, 60),
    'text_light': (120, 60, 80),
    'heart': (255, 100, 130),
    'heart_light': (255, 150, 170),
    'title': (180, 80, 110),
    'subtitle': (160, 100, 120),
    'gold': (255, 215, 0),
    'white': (255, 255, 255),
}

# 关怀话语库
DO_MESSAGES = [
    "多喝温热水，让身体暖暖的",
    "下雨晚上会降温，小肚子要保暖哦",
    "早点休息，不要熬夜啦",
    "吃点红枣桂圆，补补气血",
    "泡个热水脚，可以放松一下",
    "听点轻音乐，心情会好很多",
    "穿暖和点，别着凉啦",
    "适当走动走动，促进血液循环",
    "抱抱自己，你是最棒的",
    "累了就躺下，身体最重要",
    "喝点姜茶，暖暖胃",
    "保持心情愉快，会好很多",
    "给你揉揉肚子",
    "吃些温热的粥，养胃又暖心",
    "深呼吸，放松，生理期马上会过去的",
    "虽然没给你发很多信息，但我想你，见不到你给你发更多的信息，我会更想你"
    "给自己买点喜欢的小零食",
    "看喜欢的电影转移注意力",
    "睡个懒觉，允许自己赖床",
    "用温水袋敷敷肚子，会舒服很多",
    "告诉自己：这几天过去又是元气满满",
    "照顾自己"
    "你不要觉得我不给你发信息就是不在乎你，我虽然不怕打扰你，但你好像不太会发信息"
    "因为你发的表情小人很多一样的，我有时会理解成同样的意思，我也想你多和我说话,你为啥没给我发信息"
    "你没给我发信息的时候，我只能找点事干干了，但你却一直不给我发嘎，器鼠了"
]

DONT_MESSAGES = [
    "不要吃冰淇淋和冷饮哦",
    "别喝冰的，会刺激小肚子",
    "不要剧烈运动，身体需要休息",
    "别熬夜刷手机，早点睡",
    "不要生气和焦虑，情绪会加重不适",
    "别吃太咸的实物",
    "不要穿露脐装，肚子要保暖",
    "别喝咖啡和浓茶，会加重不适",
    "不要憋尿，对身体不好",
    "别吃生冷海鲜，容易腹泻",
    "不要久坐不动，适当起来走走",
    "别吃辛辣刺激的食物",
    "不要硬撑，该放松就放松",
    "别洗冷水澡，要温水淋浴",
    "别吃太甜的东西",
    "不要忽视身体的信号，难受要说",
    "不太懂具体哪天来，但我关心你，不要胡思乱想哇",
]

@dataclass
class Bubble:
    x: float
    y: float
    text: str
    color: tuple
    border_color: tuple
    speed_y: float
    opacity: int
    is_do: bool
    wobble_offset: float
    wobble_speed: float
    target_radius: float
    current_radius: float

class Particle:
    def __init__(self, x, y, color, speed_mult=1.0):
        self.x = x
        self.y = y
        self.color = color
        self.size = random.uniform(2, 6)
        angle = random.uniform(0, math.pi * 2)
        speed = random.uniform(1, 4) * speed_mult
        self.speed_x = math.cos(angle) * speed
        self.speed_y = math.sin(angle) * speed
        self.life = 255
        self.decay = random.uniform(2, 6)
        self.gravity = 0.05

    def update(self):
        self.x += self.speed_x
        self.y += self.speed_y
        self.speed_y += self.gravity
        self.life -= self.decay
        self.size = max(0, self.size - 0.03)

    def draw(self, surface):
        if self.life > 0 and self.size > 0:
            alpha = max(0, min(255, int(self.life)))
            s = pygame.Surface((int(self.size * 2) + 1, int(self.size * 2) + 1), pygame.SRCALPHA)
            pygame.draw.circle(s, (*self.color, alpha), (int(self.size), int(self.size)), int(self.size))
            surface.blit(s, (int(self.x - self.size), int(self.y - self.size)))

class Heart:
    def __init__(self, x=None, y=None, size=None, speed=None):
        self.x = x if x is not None else random.randint(20, SCREEN_WIDTH - 20)
        self.y = y if y is not None else SCREEN_HEIGHT + 20
        self.size = size if size is not None else random.randint(10, 20)
        self.speed = speed if speed is not None else random.uniform(0.5, 1.5)
        self.wobble = random.uniform(0, math.pi * 2)
        self.wobble_speed = random.uniform(0.02, 0.05)
        self.color = random.choice([COLORS['heart'], COLORS['heart_light']])
        self.opacity = random.randint(100, 200)

    def update(self):
        self.y -= self.speed
        self.wobble += self.wobble_speed
        self.x += math.sin(self.wobble) * 0.5

    def draw(self, surface):
        if self.y < -50:
            return
        heart_surface = pygame.Surface((int(self.size * 2.5), int(self.size * 2.5)), pygame.SRCALPHA)
        points = []
        for i in range(100):
            t = i / 100.0 * math.pi * 2
            hx = self.size * 16 * (math.sin(t) ** 3) / 16
            hy = -self.size * (13 * math.cos(t) - 5 * math.cos(2*t) - 2 * math.cos(3*t) - math.cos(4*t)) / 16
            points.append((hx + self.size, hy + self.size))
        pygame.draw.polygon(heart_surface, (*self.color, self.opacity), points)
        surface.blit(heart_surface, (int(self.x - self.size), int(self.y - self.size)))

    def is_off_screen(self):
        return self.y < -50

def wrap_text_by_chars(text, chars_per_line):
    """按固定字符数换行（中文等宽，更可靠）"""
    lines = []
    for i in range(0, len(text), chars_per_line):
        lines.append(text[i:i + chars_per_line])
    return lines

def find_chinese_font():
    """跨平台查找中文字体"""
    font_paths = [
        "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        "/usr/share/fonts/truetype/noto/NotoSansCJK-Regular.ttc",
        "/System/Library/Fonts/PingFang.ttc",
        "/System/Library/Fonts/STHeiti Light.ttc",
        "/Library/Fonts/Arial Unicode.ttf",
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/msyhbd.ttc",
        "C:/Windows/Fonts/simhei.ttf",
        "C:/Windows/Fonts/simsun.ttc",
        "C:/Windows/Fonts/simkai.ttf",
        "C:/Windows/Fonts/arialuni.ttf",
    ]
    for path in font_paths:
        if os.path.exists(path):
            return path
    return None

class PeriodCareApp:
    def __init__(self):
        self.clock = pygame.time.Clock()
        self.bubbles: List[Bubble] = []
        self.particles: List[Particle] = []
        self.hearts: List[Heart] = []
        self.spawn_timer = 0
        self.spawn_interval = 90
        self.running = True
        self.state = "playing"  # playing, ending, finished
        self.ending_timer = 0
        self.ending_phase = 0

        # 话语池（去重）
        self.do_pool = DO_MESSAGES.copy()
        self.dont_pool = DONT_MESSAGES.copy()
        random.shuffle(self.do_pool)
        random.shuffle(self.dont_pool)
        self.all_messages = []
        # 交替插入 do 和 dont
        do_idx, dont_idx = 0, 0
        while do_idx < len(self.do_pool) or dont_idx < len(self.dont_pool):
            if do_idx < len(self.do_pool):
                self.all_messages.append((self.do_pool[do_idx], True))
                do_idx += 1
            if dont_idx < len(self.dont_pool):
                self.all_messages.append((self.dont_pool[dont_idx], False))
                dont_idx += 1
        self.message_index = 0
        self.total_messages = len(self.all_messages)

        # 字体
        self.fonts = self._load_fonts()
        self.title_font = self.fonts['title']
        self.subtitle_font = self.fonts['subtitle']
        self.bubble_font = self.fonts['bubble']
        self.small_font = self.fonts['small']
        self.big_font = self.fonts['big']

        # 背景
        self.bg_surface = self._create_background()

        # 预计算每行字符数（基于字体大小）
        test_char = self.bubble_font.render("中", True, (0,0,0))
        self.char_width = test_char.get_width()
        self.chars_per_line = max(6, 220 // max(1, self.char_width))

    def _load_fonts(self):
        font_path = find_chinese_font()
        if font_path:
            try:
                return {
                    'title': pygame.font.Font(font_path, 36),
                    'subtitle': pygame.font.Font(font_path, 20),
                    'bubble': pygame.font.Font(font_path, 20),
                    'small': pygame.font.Font(font_path, 16),
                    'big': pygame.font.Font(font_path, 48),
                }
            except Exception:
                pass

        chinese_font_names = ['simhei', 'microsoftyahei', 'microsoftyaheibold',
                              'simsun', 'nsimsun', 'fangsong', 'kaiti',
                              'pingfang', 'heiti', 'wenquanyizenhei',
                              'notosanscjksc', 'notosanscjk']
        font = None
        for name in chinese_font_names:
            try:
                test = pygame.font.SysFont(name, 20)
                if test.size("测试")[0] > 0:
                    font = name
                    break
            except:
                continue

        if font:
            return {
                'title': pygame.font.SysFont(font, 36),
                'subtitle': pygame.font.SysFont(font, 20),
                'bubble': pygame.font.SysFont(font, 20),
                'small': pygame.font.SysFont(font, 16),
                'big': pygame.font.SysFont(font, 48),
            }
        else:
            return {
                'title': pygame.font.Font(None, 36),
                'subtitle': pygame.font.Font(None, 20),
                'bubble': pygame.font.Font(None, 20),
                'small': pygame.font.Font(None, 16),
                'big': pygame.font.Font(None, 48),
            }

    def _create_background(self):
        surface = pygame.Surface((SCREEN_WIDTH, SCREEN_HEIGHT))
        for y in range(SCREEN_HEIGHT):
            ratio = y / SCREEN_HEIGHT
            r = int(COLORS['bg_top'][0] + (COLORS['bg_bottom'][0] - COLORS['bg_top'][0]) * ratio)
            g = int(COLORS['bg_top'][1] + (COLORS['bg_bottom'][1] - COLORS['bg_top'][1]) * ratio)
            b = int(COLORS['bg_top'][2] + (COLORS['bg_bottom'][2] - COLORS['bg_top'][2]) * ratio)
            pygame.draw.line(surface, (r, g, b), (0, y), (SCREEN_WIDTH, y))
        return surface

    def spawn_bubble(self):
        """生成新气泡，每句只出现一次"""
        if self.message_index >= len(self.all_messages):
            return False

        text, is_do = self.all_messages[self.message_index]
        self.message_index += 1

        # 确保气泡不超出屏幕：根据文字宽度计算合适的x位置
        lines = wrap_text_by_chars(text, self.chars_per_line)
        line_height = self.bubble_font.get_height()
        text_width = max(self.bubble_font.size(line)[0] for line in lines)
        bubble_width = max(text_width + 50, 180)

        # 限制气泡位置，确保完整显示在屏幕内
        min_x = bubble_width // 2 + 20
        max_x = SCREEN_WIDTH - bubble_width // 2 - 20
        x = random.randint(min_x, max(max_x, min_x))

        if is_do:
            color = COLORS['bubble_do']
            border_color = COLORS['bubble_do_border']
        else:
            color = COLORS['bubble_dont']
            border_color = COLORS['bubble_dont_border']

        bubble = Bubble(
            x=float(x), y=SCREEN_HEIGHT + 80, text=text,
            color=color, border_color=border_color,
            speed_y=random.uniform(0.8, 1.5),
            opacity=0, is_do=is_do,
            wobble_offset=random.uniform(0, math.pi * 2),
            wobble_speed=random.uniform(0.01, 0.03),
            target_radius=1.0, current_radius=0.0
        )
        self.bubbles.append(bubble)
        return True

    def update_bubbles(self):
        for bubble in self.bubbles:
            bubble.y -= bubble.speed_y
            bubble.wobble_offset += bubble.wobble_speed
            bubble.x += math.sin(bubble.wobble_offset) * 0.3

            # 淡入
            if bubble.y > SCREEN_HEIGHT - 120:
                bubble.opacity = min(255, bubble.opacity + 6)
            # 淡出
            elif bubble.y < 120:
                bubble.opacity = max(0, bubble.opacity - 4)
            else:
                bubble.opacity = min(255, bubble.opacity + 3)

        self.bubbles = [b for b in self.bubbles if b.y > -120 and b.opacity > 0]

    def draw_bubble(self, surface, bubble):
        if bubble.opacity <= 0:
            return

        lines = wrap_text_by_chars(bubble.text, self.chars_per_line)
        line_height = self.bubble_font.get_height()
        text_height = len(lines) * line_height + 25
        text_width = max(self.bubble_font.size(line)[0] for line in lines)

        bubble_width = max(text_width + 50, 180)
        bubble_height = max(text_height, 65)

        bx = int(bubble.x - bubble_width / 2)
        by = int(bubble.y - bubble_height / 2)

        # 确保不绘制在标题区域（y < 100）
        if by < 100:
            by = 100

        bubble_surface = pygame.Surface((bubble_width + 20, bubble_height + 25), pygame.SRCALPHA)

        # 阴影
        shadow_color = (0, 0, 0, min(25, bubble.opacity // 10))
        pygame.draw.ellipse(bubble_surface, shadow_color,
                           (6, 6, bubble_width, bubble_height))

        # 主体
        bg_color = (*bubble.color, min(230, bubble.opacity))
        border_color = (*bubble.border_color, min(255, bubble.opacity))

        pygame.draw.ellipse(bubble_surface, bg_color,
                           (0, 0, bubble_width, bubble_height))
        pygame.draw.ellipse(bubble_surface, border_color,
                           (0, 0, bubble_width, bubble_height), 2)

        # 高光
        highlight = pygame.Surface((bubble_width - 30, bubble_height // 3), pygame.SRCALPHA)
        pygame.draw.ellipse(highlight, (255, 255, 255, min(50, bubble.opacity // 5)),
                           (0, 0, bubble_width - 30, bubble_height // 3))
        bubble_surface.blit(highlight, (15, 6))

        # 小尾巴
        tail_points = [
            (bubble_width // 2 - 10, bubble_height - 2),
            (bubble_width // 2, bubble_height + 14),
            (bubble_width // 2 + 10, bubble_height - 2),
        ]
        pygame.draw.polygon(bubble_surface, bg_color, tail_points)
        pygame.draw.polygon(bubble_surface, border_color, tail_points, 1)

        # 标签
        label = "z" if bubble.is_do else "c"
        label_color = (60, 130, 60) if bubble.is_do else (170, 70, 70)
        label_surface = self.small_font.render(label, True, label_color)
        label_surface.set_alpha(min(255, bubble.opacity))
        bubble_surface.blit(label_surface, (18, 10))

        # 文字内容
        text_y = 30 + (bubble_height - 30 - len(lines) * line_height) // 2
        for i, line in enumerate(lines):
            text_surface = self.bubble_font.render(line, True, COLORS['text_dark'])
            text_surface.set_alpha(min(255, bubble.opacity))
            text_x = (bubble_width - text_surface.get_width()) // 2
            bubble_surface.blit(text_surface, (text_x, text_y + i * line_height))

        surface.blit(bubble_surface, (bx - 10, by - 10))

    def update_particles(self):
        for p in self.particles:
            p.update()
        self.particles = [p for p in self.particles if p.life > 0]

    def update_hearts(self):
        for heart in self.hearts:
            heart.update()
        self.hearts = [h for h in self.hearts if not h.is_off_screen()]
        if random.random() < 0.03:
            self.hearts.append(Heart())

    def draw_title(self, surface):
        title_bg = pygame.Surface((SCREEN_WIDTH, 100), pygame.SRCALPHA)
        pygame.draw.rect(title_bg, (255, 255, 255, 180), (0, 0, SCREEN_WIDTH, 100))
        surface.blit(title_bg, (0, 0))

        title = self.title_font.render("生理期关怀小助手", True, COLORS['title'])
        title_x = (SCREEN_WIDTH - title.get_width()) // 2
        surface.blit(title, (title_x, 15))

        subtitle = self.subtitle_font.render("愿你被温柔以待，每一天都暖暖的", True, COLORS['subtitle'])
        subtitle_x = (SCREEN_WIDTH - subtitle.get_width()) // 2
        surface.blit(subtitle, (subtitle_x, 60))

        pygame.draw.line(surface, (220, 180, 190), (100, 95), (SCREEN_WIDTH - 100, 95), 2)

    def draw_progress(self, surface):
        """绘制进度条"""
        if self.total_messages == 0:
            return
        progress = self.message_index / self.total_messages
        bar_width = 200
        bar_height = 8
        bar_x = (SCREEN_WIDTH - bar_width) // 2
        bar_y = SCREEN_HEIGHT - 35

        # 背景
        pygame.draw.rect(surface, (220, 200, 210), (bar_x, bar_y, bar_width, bar_height), border_radius=4)
        # 进度
        fill_width = int(bar_width * progress)
        if fill_width > 0:
            pygame.draw.rect(surface, COLORS['heart'], (bar_x, bar_y, fill_width, bar_height), border_radius=4)

        text = self.small_font.render(f"{self.message_index}/{self.total_messages}", True, COLORS['text_light'])
        surface.blit(text, (bar_x + bar_width + 10, bar_y - 3))

    def draw_ending(self, surface):
        """播放完毕的结束动画"""
        self.ending_timer += 1

        # 阶段1：爱心爆发（0-120帧）
        if self.ending_phase == 0:
            if self.ending_timer % 3 == 0:
                for _ in range(3):
                    x = random.randint(50, SCREEN_WIDTH - 50)
                    y = random.randint(50, SCREEN_HEIGHT - 50)
                    self.particles.append(Particle(x, y, random.choice([COLORS['heart'], COLORS['heart_light'], COLORS['gold']]), speed_mult=2.0))
            if self.ending_timer > 120:
                self.ending_phase = 1
                self.ending_timer = 0

        # 阶段2：大爱心浮现（120-300帧）
        elif self.ending_phase == 1:
            center_x, center_y = SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2 - 30
            scale = min(1.0, self.ending_timer / 60)
            opacity = min(255, self.ending_timer * 2)

            size = int(60 * scale)
            if size > 5:
                heart_surf = pygame.Surface((size * 3, size * 3), pygame.SRCALPHA)
                points = []
                for i in range(100):
                    t = i / 100.0 * math.pi * 2
                    hx = size * 16 * (math.sin(t) ** 3) / 16
                    hy = -size * (13 * math.cos(t) - 5 * math.cos(2*t) - 2 * math.cos(3*t) - math.cos(4*t)) / 16
                    points.append((hx + size * 1.5, hy + size * 1.5))
                pygame.draw.polygon(heart_surf, (*COLORS['heart'], opacity), points)
                surface.blit(heart_surf, (center_x - int(size * 1.5), center_y - int(size * 1.5)))

            # 文字淡入
            if self.ending_timer > 40:
                text_opacity = min(255, (self.ending_timer - 40) * 3)
                texts = [
                    ("所有关怀已送达", self.big_font, center_y + size + 40),
                    ("记得好好照顾自己哦", self.subtitle_font, center_y + size + 95),
                    ("我一直都很想你是真的", self.small_font, center_y + size + 140),
                ]
                for text, font, y_pos in texts:
                    surf = font.render(text, True, COLORS['title'])
                    surf.set_alpha(text_opacity)
                    x_pos = (SCREEN_WIDTH - surf.get_width()) // 2
                    surface.blit(surf, (x_pos, y_pos))

            # 持续飘爱心
            if random.random() < 0.1:
                self.hearts.append(Heart(
                    x=random.randint(20, SCREEN_WIDTH - 20),
                    y=SCREEN_HEIGHT + 20,
                    size=random.randint(8, 18),
                    speed=random.uniform(0.8, 2.0)
                ))

    def check_click(self, pos):
        for bubble in self.bubbles[:]:
            lines = wrap_text_by_chars(bubble.text, self.chars_per_line)
            line_height = self.bubble_font.get_height()
            text_height = len(lines) * line_height + 25
            text_width = max(self.bubble_font.size(line)[0] for line in lines)
            bubble_width = max(text_width + 50, 180)
            bubble_height = max(text_height, 65)

            bx = bubble.x - bubble_width / 2 - 10
            by = max(100, bubble.y - bubble_height / 2 - 10)

            if bx <= pos[0] <= bx + bubble_width + 20 and by <= pos[1] <= by + bubble_height + 25:
                for _ in range(15):
                    self.particles.append(Particle(bubble.x, bubble.y, bubble.color))
                if bubble in self.bubbles:
                    self.bubbles.remove(bubble)
                break

    def reset(self):
        """重新开始"""
        self.do_pool = DO_MESSAGES.copy()
        self.dont_pool = DONT_MESSAGES.copy()
        random.shuffle(self.do_pool)
        random.shuffle(self.dont_pool)
        self.all_messages = []
        do_idx, dont_idx = 0, 0
        while do_idx < len(self.do_pool) or dont_idx < len(self.dont_pool):
            if do_idx < len(self.do_pool):
                self.all_messages.append((self.do_pool[do_idx], True))
                do_idx += 1
            if dont_idx < len(self.dont_pool):
                self.all_messages.append((self.dont_pool[dont_idx], False))
                dont_idx += 1
        self.message_index = 0
        self.bubbles.clear()
        self.particles.clear()
        self.hearts.clear()
        self.state = "playing"
        self.ending_timer = 0
        self.ending_phase = 0
        self.spawn_timer = 0

    def run(self):
        while self.running:
            dt = self.clock.tick(60)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        self.running = False
                    elif event.key == pygame.K_r and self.state == "finished":
                        self.reset()
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if self.state == "playing":
                        self.check_click(event.pos)

            # 更新
            self.update_bubbles()
            self.update_particles()
            self.update_hearts()

            # 绘制背景
            screen.blit(self.bg_surface, (0, 0))

            # 绘制爱心
            for heart in self.hearts:
                heart.draw(screen)

            if self.state == "playing":
                # 生成气泡
                self.spawn_timer += 1
                if self.spawn_timer >= self.spawn_interval:
                    spawned = self.spawn_bubble()
                    self.spawn_timer = 0
                    if not spawned and len(self.bubbles) == 0:
                        # 所有话语播放完毕，进入结束动画
                        self.state = "finished"
                        self.ending_timer = 0
                        self.ending_phase = 0

            # 绘制气泡
            for bubble in self.bubbles:
                self.draw_bubble(screen, bubble)

            # 绘制粒子
            for particle in self.particles:
                particle.draw(screen)

            # 绘制标题
            self.draw_title(screen)

            if self.state == "playing":
                self.draw_progress(screen)
            elif self.state == "finished":
                self.draw_ending(screen)

            pygame.display.flip()

        pygame.quit()
        sys.exit()

if __name__ == "__main__":
    app = PeriodCareApp()
    app.run()