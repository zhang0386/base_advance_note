# 1.自定义SingleNode类，表示 节点类
class SingleNode:
    def __init__(self,item):
        self.item = item        # 数值域(元素域)
        self.next = None        # 地址域(链接域)

# 1.自定义SingleLinkedList类，表示： 链表
class SingleLinkedList:
    def __init__(self,node=None):
        self.head = node

    # 2.is_empty(self) 链表是否为空
    def is_empty(self):
        # 思路：判断头结点是否为None，如果为None，则链表为空
        # 写法1：if else
        # if self.head == None:
        #     return True
        # else:
        #     return False

        # 写法2：三元表达式
        # return True if self.head is None else False

        # 写法3：最终版
        return self.head is None

    # 3.length(self)    链表长度
    def length(self):
        # 3.1创建游标(表示当前结点)，默认从头结点开始
        cur = self.head
        # 3.2定义计数器
        count = 0
        # 3.3开始遍历，只要当前结点不为空，就一直循环
        if cur is not None:
            # 3.4计数器 + 1，然后，cur指向下一个结点
            count += 1
            cur = cur.next
        # 返回链表长度
        return count

    # 4.travel(self. )  遍历整个链表
    def travel(self):
        # 4.1创建游标，默认从头结点开始
        cur = self.head
        # 4.2只要当前结点不为空，就一直循环
        while cur is not None:
            # 4.3打印当前结点的数值域
            print(f"数值域： {cur.item}")
            # 4.4修改当前节点，然后指向下一个结点
            cur = cur.next


    # 5.add(self,item)  链表头部添加元素
    def add(self,item):
        # 5.1创建新节点
        new_node = SingleNode(item)
        # 5.2设置新节点指向头结点
        new_node.next = self.head
        # 5.3设置头结点指向新节点
        self.head = new_node

    # append(self,item) 链表尾部添加元素
    def append(self):
        pass

    # insert(self, pos, item) 指定位置添加元素
    def insert(self):
        pass

    # remove(self,item) 删除节点
    def remove(self):
        pass

    # search(self,item) 查找节点是否存在
    def search(self):
        pass

if __name__ == '__main__':
    # 2.测试is_empty函数
    # 2.1创建节点类
    node2 = SingleNode('会襄')
    # 2.2将上述的节点作为头结点，创建链表
    my_linkedlist = SingleLinkedList(node2)
    print('-'*23)

    # 2.3测试链表是否为空
    print(my_linkedlist.is_empty())
    print('-'*23)

    # 5.测试链表头部添加元素
    my_linkedlist.add('晴天')
    my_linkedlist.add('雨天')

    # 3.测试链表长度
    print(f"链表长度为：{my_linkedlist.length()}")
    print('-'*23)

    # 4.测试遍历列表
    my_linkedlist.travel()