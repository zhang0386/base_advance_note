"""
案例：演示正则表达式之 校验邮箱

        |           代表 或者的意思
        ()          代表 分组，从左往右数，第几个左小括号(,就表示第几组
        \num        代表 引用第几组内容

        扩展:
            (?P<分组名>)    设置分组
            (？P=分组名)    使用分组
"""
# 导包
import re

# 定义随机邮箱
email = 'abcd@qq.com'

# 校验邮箱是否合法
result = re.match(r'^[a-zA-Z0-9_]{4,20}@(126|qq|163)\.com$',email)

# 输出相关判断结果
if result:
    print(f'合法邮箱为：{result.group()}')        # abcd@qq.com
    print(f'合法邮箱为：{result.group(0)}')       # abcd@qq.com
    print(f'合法邮箱为：{result.group(1)}')       # qq
else:
    print("邮箱不合法！")