"""
案例：演示自定义迭代器

迭代器介绍：
    概述：
        自定义的类，只要重写了__iter__()和__next__()方法，就可以称为迭代器
    目的：
        隐藏底层的逻辑，让用户使用更方便
        惰性加载，用的时候才会获取

回顾：for循环格式
    for i in 数据容器:
        pass
"""
# 模拟range(1,6)，自定义迭代器实现同等逻辑
for i in range(1,6):
    print(i)
print('*'*34)

# 自定义迭代器
class MyIterator:
    # 初始化属性
    def __init__(self,start,end):
        self.current_value = start
        self.end = end

    # 重写iterator魔法方法，返回当前对象(即：迭代器的对象)
    def __iter__(self):
        return self

    # 重写next魔法方法，返回当前值，并更新当前值
    def __next__(self):
        if self.current_value >= self.end:
            raise StopIteration     # 抛出异常，迭代结束
        value = self.current_value
        self.current_value += 1
        return  value

# for循环迭代
for i in MyIterator(1,6):
    print(i)
print('-'*34)

# next()函数：指向下一个元素的地址
my_itr = MyIterator(6,9)
print(next(my_itr))     # 6
print(next(my_itr))     # 7
print(next(my_itr))     # 8
# print(next(my_itr))       #raise StopIteration     # 抛出异常，迭代结束
