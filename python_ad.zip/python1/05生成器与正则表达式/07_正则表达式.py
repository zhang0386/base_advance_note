"""
案例：演示正则表达式之 校验单个字符

正则表达式介绍：
    概述：
        正确的，符合特定规则的 字符串
        Regular Expression，正则表达式，简称：re
    细节：
        1.学会正则表达式，就是学正则表达式的规则，不用背，网上搜
        2.关于正则，看懂别人写的式子，且简单修改即可
        3.正则不独属于Python，像Java，JavaScript，PHP，Go等都支持
    步骤：
        1.导包
            import re
        2.正则匹配
            result = re.match('正则表达式','要校验的字符串')   从前往后依次匹配
            result = re.search('正则表达式','要校验的字符串')   分段查找
        3.获取匹配结果
            result.group()
    正则常用的规则：
        .           代表任意的1个字符，除了\n
        \.          取消.的特殊含义，就是1个普通的.
        a           代表1个普通的字符a
        [abc]       代表a,b,c中任意的1个的字符
        [^abc]      代表除了a,b,c外，任意的一个字符
        \d          代表数字，等价于[0-9]
        \D          代表非数字，等价于[^0-9]
        \s          代表空白字符，等价于[\t\n\r]
        \S          代表非空白字符
        \w          代表非特殊字符，即：数字，字母，下划线，汉字，[a-z A-Z 0-9 _ 汉字]
        \W          代表特殊字符，非字符，数字，下划线，汉字

        ^           表示开头
        $           表示结尾

        *           代表前边的内容 出现至少0次，至多无数次
        ?           代表前边的内容 出现至少0次，至多1次
        +           代表前边的内容 出现至少1次，至多无数次
        {n}         代表前边的内容 恰好出现n次
        {n,}        代表前边的内容 出现至少n次，至多无数次
        {n,m}       代表前边的内容 出现至少n次，至多m次，包左包右

        |           代表 或者的意思
        ()          代表 分组，从左往右数，第几个左小括号(,就表示第几组
        \num        代表 引用第几组内容

        扩展:
            (?P<分组名>)    设置分组
            (？P=分组名)    使用分组
"""
# 1.导包
import re

# 2.正则校验
# result = re.match('.it','ait')      # 匹配成功
# result = re.match('.it','aithlxt')      # 匹配成功
# result = re.match('.itx','aithlxt')      # 失败
# result = re.match('.it','\nait')    # 失败
# result = re.match('.it','\tait')    # 失败

# result = re.match('\.it','ait')    # 失败

# result = re.match('it','itaaa')    # 匹配成功
# result = re.match('[abc]it','bitaaa')    # 匹配成功
# result = re.match('[^bhj]it','litaaa')    # 匹配成功
# result = re.search('\d.*','klo<>/?1.beijing/2.dongGuan')    # 匹配成功

# # *代表前边的内容，出现至少0次，至多无数次
# result = re.match('.*abc.*','hlxtabcllo/.')     # 匹配成功
# # ?代表前边的内容,出现至少0次，至多1次
# result = re.match('.?hlxt','thlxtll')            # 匹配成功
# # +代表前边的内容,出现至少1次，至多无数次
# result = re.match('.+hlxt','0999hlxtabc')              # 匹配成功
# # {n}代表前边的内容,恰好出现n次
# result = re.match('.{3}jpo.{2,5}','klljpooop')           # 匹配成功
# # {n, }代表前边的内容,出现至少n次，至多无数次
# result = re.match(r'\d{2,}abc123','0055abc123io')       # 匹配成功
# # {n, m}代表前边的内容,出现至少n次，至多m次，包左包右
# result = re.match(r'.{1,3}abc','12@abc')            # 匹配成功

# # ^ 表示开头
# result = re.match(r'\d{3}.*','123abc你好')
# # $ 表示结尾
# result = re.match(r'\d{3}.*\w{3}$','123abc你好almd')

# 需求1：校验手机号，规则：1.长度必须是11位，2.必须是纯数字。3.第一位必须是1，4.第2位可以是3-9
result = re.match(r'^1[3-9]\d{9}$','13119627398')
# 3.获取匹配结果
print(result.group() if result else '匹配失败')
# if result:
#     print(result.group())
# else:
#     print('匹配失败')