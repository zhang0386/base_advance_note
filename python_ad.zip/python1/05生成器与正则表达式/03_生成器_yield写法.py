"""
案例：演示生成器之 推导式写法

生成器介绍：
    概述：
        所谓的生成器就是基于 数据规则，用一部分再生成一部分，而不是一下子生成完所有.
    目的：
        可以节省大量的内容
    实现方式：
        1.推导式写法
        2.yield关键字
"""
# 回顾：推导式写法
my_gt = (i for i in range(1,11))

# yield方式如下：
# 定义函数，存储到生成器中，并返回
def my_fun():
    # my_list = []
    # for i in range(1,11):
    #     my_list.append(i)
    # return my_list

    # 效果类似于上边代码
    # yield完成：1.创建生成器对象。2.把值储存到生成器中。3.返回生成器
    for i in range(1,11):
        yield i

my_gt1 = my_fun()
print(type(my_gt1))         #  <class 'generator'>

print(next(my_gt1))
print(next(my_gt1))
print('-'*23)
for i in my_gt1:
    print(i)