"""
案例：演示正则替换
步骤：
        1.导包
            import re
        2.正则匹配
            result = re.match('正则表达式','要校验的字符串')   从前往后依次匹配
            result = re.search('正则表达式','要校验的字符串')   分段查找
            result = re.compile('正则表达式').sub(替换后的内容，要求被替换后的字符串)     替换
        3.获取匹配结果
            result.group()
"""
# 导包
import re

# 1.定义字符串
s = '开心就好,哈哈,嘿嘿,嚯嚯,桀桀桀,嘻嘻,啦啦啦'

# 2.把上述的 哈,嘿,嚯,桀,嘻, 替换为 ❤
result = re.compile('哈|嘿|嚯|桀|嘻').sub('❤',s)

# 3.打印结果
print(result)
print('-'*23)

# 新版API的写法
# 参数1：正则规则 ,参数2：新字符串，参3：要被替换的字符串
result = re.sub('哈|嘿|嚯|桀|嘻','♠',s)
print(result)