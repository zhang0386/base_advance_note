"""
案例：演示正则表达式之 校验邮箱

        |           代表 或者的意思
        ()          代表 分组，从左往右数，第几个左小括号(,就表示第几组
        \num        代表 引用第几组内容

        扩展:
            (?P<分组名>)    设置分组
            (？P=分组名)    使用分组
"""
# 导包
import re

# 定义qq号
s = 'qq:12345678912'

# 正则表达式
result = re.match(r'^(qq):(\d{5,11})$',s)

# 打印结果
if result:
    print(result.group())
    print(result.group(0))      # 效果同上
    print('-'*23)

    print(result.group(1))      # qq
    print(result.group(2))      # qq号
else:
    print("未匹配")