"""
案例：演示property属性的用法

property属性介绍：
    概述/目的/作用：
        把函数当作属性来用
    实现方式：
        方式1：装饰器
        方式2：类属性

property的装饰器用法：
    @property               修饰 获取值的函数
    @获取值的函数名.setter     修饰 设置值的函数

    之后，就可以直接，上述的函数名 来当作变量直接用
"""
# 需求：定义学生类，私有属性 age ，通过property实现简化调用
# 定义学生类
class Student:
    def __init__(self):
        # 私有属性
        self.__age = 8

    # 提供公共的访问方式
    @property
    def age(self):
        return self.__age

    @age.setter         # 不能写return语句
    def age(self,new_age):
        self.__age = new_age

if __name__ == '__main__':
    # 创建学生对象
    s = Student()
    # 设置值
    s.age = 20
    # 获取值
    print(s.age)


