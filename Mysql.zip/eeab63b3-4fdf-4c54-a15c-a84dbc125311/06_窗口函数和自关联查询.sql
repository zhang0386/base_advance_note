# -------------------- 案例1:窗口函数(Mysql8.X 新特性) --------------------
/*
窗口函数解释:
    概述:
        它是MySQL8.X的新特性，主要用于 给数据表新增1列，至于新增的内容是什么，取决于你用什么窗口函数
    格式:
        窗口函数 over([partition by 分组字段 order by 排序字段 asc | desc])
    常用的窗口函数:假设数据集是 100，90，90，60，即三个函数的排名结果分别是:
        row_number(): 做行号标记的，即1,2,3,4
        rank():       做稀疏排名的，即1,2,2,4
        dense_rank(): 做密集排名的，即1,2,2,3
    细节:
        1.窗口函数 = 给表新增1列，至于新增的是什么，取决于和什么函数一起用
        2.如果不写partition by，则统计的是全表数据，写了则统计的是组内数据
        3.如果不写order by，则统计的是组内所有的数据，写了则统计的是组内从第一行，截止到当前行
        4.可以尝试其他窗口函数结合over()一起用
            例如:count(),max(),min(),sum(),avg(),ntile(n),lag(),lead(),first_value(),last_value()...
 */
# 准备数据  → 建库，切库，查表
create database demo3;
use demo3;
show tables;

# 准备数据 → 建表，添加数据
create table employee (
    empid int,
    ename varchar(20),
    deptid int,
    salary decimal(10,2)
);

insert into employee values(1,'刘备',10,5500.00);
insert into employee values(2,'赵云',10,4500.00);
insert into employee values(2,'张飞',10,3500.00);
insert into employee values(2,'关羽',10,4500.00);

insert into employee values(3,'曹操',20,1900.00);
insert into employee values(4,'许褚',20,4800.00);
insert into employee values(5,'张辽',20,6500.00);
insert into employee values(6,'徐晃',20,14500.00);

insert into employee values(7,'孙权',30,44500.00);
insert into employee values(8,'周瑜',30,6500.00);
insert into employee values(9,'陆逊',30,7500.00);

# 查看数据
select * from employee;

# 案例1：分组排名，需求：按照部门id(deptid)分组，按工资(salary)降序排列
# 场景1：给表新增1列
select *,10/3 from employee;

# 场景2：引入窗口函数
select
    *,
    # sum(salary) over () as total_sum                         # 没写partition by统计全表，这里是统计占比
    # sum(salary) over (partition by deptid) as total_sum        # 写partition by统计全组，这里是统计占比
    sum(salary) over (partition by deptid order by salary) as total_sum        # 写partition by统计全组，这里是统计占比
from
    employee;

# 场景3：按照部门id(deptid)分组，按工资(salary)降序排列
select
    *,
    row_number() over(partition by deptid order by salary desc) as rn,
    rank() over(partition by deptid order by salary desc) as rk,
    dense_rank() over(partition by deptid order by salary desc) as dr
from
    employee;

# 场景4:分组排名求TopN，需求:找出每组工资最高的2人的信息(考虑并列).
# 如下代码思路没问题，但语法有误，因为where后面的字段必须是biaozj=hong 已有的字段
select
    *,
    rank() over (partition by deptid order by salary desc) rk
from
    employee
where
    rk <= 2;

# 思路1：解决方案，再包裹一层(子查询)
select * from (
    select
    *,
    rank() over (partition by deptid order by salary desc) rk
from
    employee
     ) t1
where rk <= 2;

# 思路2：用CTE 公共表达式，可以把常用的数据集封装成新表，方便操作
/*
格式：
    with 表名1 as (select .....)
         表名2 as (select ....)
         .....
    select * from t1 ... # 这里正常写SQL，使用上述的 表名即可
 */
with t1 as (select *,rank() over (partition by deptid order by salary desc) rk from employee)
select * from t1 where rk <= 2;

# 扩展:1个需求表示 CTE表达式的强大之处
with t1 as (select * from employee),
     t2 as (select * from employee where deptid=10),
     t3 as (select * from employee where deptid=20),
     t4 as (select * from employee where deptid=30),
     t5 as (select *,sum(salary) over() as total_salary from employee)
select * from t5;

# -------------------- 案例2:自关联查询(自连接) --------------------
/*
解释:
    表自己和自己做 关联查询 → 自关联，自连接查询
应用场景:
    省市区(行政区域表) 信息查询.
如果不考虑自连接，用行政区域表，要求有 行政区域id 和 行政区域名 410000 → 河南省，要建多表关联
合并之后，表中有3个字段，分别是:
    区域自身id      区域名     区域的父级id
    410000        河南省       0

    410100        郑州市       410000

    410101        二七区       410100
 */
# 查表
show tables;
# 查看表数据
select * from areas;

# 1.查看广东省的信息
select * from areas where title = '广东省';

# 2.查看广东省所有的市
select * from areas where pid = '440000';

# 3.查看茂名市所有的县区
select * from areas where pid = '440900';

# 4.查看所有者，所有市，所有区县的信息
select
    province.id,province.title,         # 省级的id，名字
    city.id,city.title,                 # 市级的id，名字
    county.id,county.title              # 区县的id，名字
from
    areas as county     # 区县表
join
    areas as city on county.pid = city.id
join
    areas as province on city.pid = province.id;

# 4.精准查找信息
select
    province.id,province.title,         # 省级的id，名字
    city.id,city.title,                 # 市级的id，名字
    county.id,county.title              # 区县的id，名字
from
    areas as county     # 区县表
join
    areas as city on county.pid = city.id
join
    areas as province on city.pid = province.id
where
    county.id = '440705';


