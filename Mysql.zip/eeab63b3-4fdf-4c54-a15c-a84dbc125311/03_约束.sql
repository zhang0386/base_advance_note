/*
约束解释:
    概述:
        就是在数据类型的基础上，进一步对某列值做限定
    分类:
        单表约束:
            primary key:主键约束,特点:非空，唯一，一般结合(auto_increment)一起使用
            not null:非空约束
            unique:唯一约束
            default:默认约束
        多表约束:
            foreign key
*/
# -------------------- 案例1:演示主键约束 --------------------
# 1.建库，切库，查表
create database if not exists demo2;
use demo2;
show tables;
# 场景1:建表时添加约束
# 0.删表
drop table student;
# 1.创建学生表，字段:id name age
create table student(
    sid int primary key,        # 学号
    name varchar(10),           # 姓名
    age int                     # 年龄
    # ,primary key(sid)         # 也可以这样设置主键id
);

# 2.查看表结构
desc student;

# 3.给student表添加数据
insert into student values(1,'张三',20);
insert into student values(1,'张三',20);      # 报错，id重复
insert into student values(null,'张三',20);      # 报错，id不能为空(细节：如果传入自增，id可以为空)

# 4.查看表数据
select * from student;

# 5.删除主键约束
alter table student drop primary key;

# 6.建表后，添加主键约束，结合自增
alter table student add primary key(sid);
alter table student modify sid int auto_increment;      # 增加 自增功能

# 7.再次尝试往表添加数据
insert into student values(2,'李四',19);
insert into student values(null,'王五',18);
insert into student values(null,'赵六',18);
insert into student values(10,'李明',19);
insert into student values(null,'王强',21)

# 8.删除表数据
delete from student where sid>=10;

# 回顾:delete from (不会重置主键id),truncate table (会重置主键id)
delete from student;
truncate table student;             # 相当于重建表

# -------------------- 案例2:演示单表约束 --------------------
# 1.查表
show tables;

# 2.建表，员工表(employee)，字段(员工id，员工姓名，员工手机号，员工性别，员工住址)
create table employee(
    eid int primary key auto_increment,
    name varchar(10) not null,
    mobile varchar(11) unique,
    gender varchar(2) not null,
    address varchar(10) default '深圳'
);

# 3.查看表结构
desc employee;

# 4.往表中添加数据
insert into employee values(null,'张三','12345678912','男','');
insert into employee(eid, name, mobile, gender) values(null,'李四','222','男');

# 5.查看表数据
select * from employee;

