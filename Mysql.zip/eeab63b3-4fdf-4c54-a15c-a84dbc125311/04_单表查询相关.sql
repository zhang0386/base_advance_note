/*
单表查询介绍:
    概述:
        所谓的单表查询，指的是 按照一定的条件，从一张SQL表中查出我们想要的结果数据
    总的格式:
        select
            [distinct] 列名 [as 别民],列名[as 别名] ...
        from
            数据表名
        where
            组前筛选
        group by
            分组字段
        having
            组后筛选
        order by
            排序的列1 [asc | desc],排序的列2...
        limit
            起始索引，数组条数;
    细节:
        1.
 */
# -------------------- 准备动作:准备数据 --------------------
# 切库
use demo3;
# 准备数据
# 0.建库，切库，查表
create database if not exists demo3;
use demo3;
show tables;
# 1.创建商品表
create table product(
    pid int primary key auto_increment,         # 商品id，主键
    pname varchar(20),                          # 商品名
    price double,                               # 商品单价
    category_id varchar(32)                        # 商品的分类id
);

# 2.添加表数据
insert into product(pid, pname, price, category_id) values(null,'联想',6100,'1');
insert into product(pid, pname, price, category_id) values(null,'戴尔',7400,'1');
insert into product(pid, pname, price, category_id) values(null,'惠普',6600,'1');
insert into product(pid, pname, price, category_id) values(null,'华硕',6900,'1');
insert into product(pid, pname, price, category_id) values(null,'华为',8400,'1');
insert into product(pid, pname, price, category_id) values(null,'苹果',12800,'2');
insert into product(pid, pname, price, category_id) values(null,'宏碁',5400,'1');
insert into product(pid, pname, price, category_id) values(null,'微星',7900,'1');
insert into product(pid, pname, price, category_id) values(null,'小米',6000,'2');
insert into product(pid, pname, price, category_id) values(null,'荣耀',5100,'1');
insert into product(pid, pname, price, category_id) values(null,'红米',3199,'2');
insert into product(pid, pname, price, category_id) values(null,'华盛顿',1000,'3');
insert into product(pid, pname, price, category_id) values(null,'伦敦',null,'3');
insert into product(pid, pname, price, category_id) values(null,'诺曼底',null,'3');

# -------------------- 案例1:简单查询 --------------------
# 1.查询表中所有的数据
# 格式:select 列名1，列名2... from 数据表名;
select pid,pname,price,category_id from product;

# 上述格式语法糖
select * from product;

# 2.查询指定列的数据，例如:商品名，价格
select pname,price from product;

# 3.别名查询
# 格式: 列名 as 别名，列名 as 别名
select pname as 商品名,price as 价格 from product as p;
select pname 商品名,price 价格 from product p;       # as可省略

# 4.修改某列值，即:查询商品名，价格，但是 价格要 +10
select pname,price+10 as price from product;

# -------------------- 案例2:条件查询 --------------------
/*
格式:
    select * from 数据表名 where 条件
条件可以是:
    1.比较运算符
        >,≥,<,≤,≠,<>,=
    2.逻辑运算符
        and,or,not
    3.like 模糊查询
        _ 代表任意的1个字符
        % 代表任意的多个字符，至少0个，至多无所谓
    4.范围查询
        between 值1 and 值2       包左不包右，适用于连续值的判断
        in (值1,值2,值3)           满足任意1个值即可，适用于 非连续值的判断
    5.空值判断
        is null 或者 is not null
*/
# 1.查询所有数据
select * from product;

# 2.需求1:查询价格大于7000的商品
select * from product where price >= 7000;

# 需求2.查询价格大不等于6600的商品
select * from product where price <> 6600;
select * from product where price != 6600;

# 需求3:查询价格在 8000~10000 的商品
select * from product where price > 8000 and price < 10000;
select * from product where price between 8000 and 10000;

# 需求4:查找 第二个字 是米的 商品信息 商品名共计两个字
select * from product where pname like '_米';
# 需求5:查找 有华字的 商品信息
select * from product where pname like '%华%';

# 需求6:查询单价是 1000，6600或者6900 的商品信息
select * from product where price in (1000,6600,6900);
select * from product where price = 1000 or price = 6600 or price = 6900;

# 需求7:查询单价 不是 1000，6600或者6900 的商品信息
select * from product where price not in (1000,6600,6900);
select * from product where price <> 1000 and price <> 6600 and price <> 6900;

# 需求8:查询没有单价的商品信息
select * from product where price is null;

# -------------------- 案例3:排序查询 --------------------
/*
格式:
    select * from 数据表名 order by 排序的列1 [asc/desc],排序的列2 [asc/desc]
细节:
    1.如果不写 asc|desc ,默认是:asc(升序)，它可以省略不写
    2.无论SQL简单还是复杂，order by都要写到语句的最后面(limit前)
*/
# 1.查看数据表
select * from product;

# 2.按照价格升序排序查询
select * from product order by price;
select * from product order by price asc;       # ascending:升序，默认的 可以不写

# 3.按照价格降序排列查询
select * from product order by price desc;      # descending:降序

# -------------------- 案例4:聚合查询 --------------------
/*
聚合函数解释:
    概述:
        它是以列为单位进行操作的，例如: 计算某列值的个数，最大值，最小值，求和，平均值等
    涉及到的函数:
        count()     一般用于 统计表的 数据条数
        sum()   求和
        max()   最大值
        min()   最小值
        avg()   平均值
 */
# 1.查询表数据
select * from product;

# 2.统计数据条数
/*
面试题:
    count(*)，count(1),count(列)的区别是什么
答案:
    1.是否统计null的值
        count(列)不统计，count(*),count(1)统计
    2.效率问题，效率从高到低分别是
        count(主键列) > count(1) > count(列) > count(*)
        主键列的底层:主键索引
*/
select count(*) from product;           # 14
select count(1) from product;           # 14
select count(price) from product;       # 12,count()统计列的时候，会忽略该列的null值

# 3.查看商品价格的 求和，最大值，最小值，平均值数据
select
    sum(price) as sum_price,
    max(price) as max_price,
    min(price) as min_price,
    avg(price) as avg_price,
    round(avg(price),2) as avg_price            # 四舍五入
from
    product;

# -------------------- 案例5:分组查询 --------------------
/*
格式:
    select
        *
    from
        数据表名
    where
        组前筛选
    group by
        分组的列1，列2...
    having
        组后筛选;
细节:
    1.根据谁分组，就根据谁查询，即:分组查询的查询列 只能出现分组字段和聚合函数
    2.面试题:where和having的区别是什么？
        1.作用不同
            组前筛选用where，组后筛选用having
        2.后边是否可以跟聚合函数
            where后边不可以，having后边可以
 */
# 1.查询表数据
select * from product;

# 2.需求:统计每个类别的商品数量，根据category_id分组，count()计数即可
select
    category_id,                # 分组字段
    count(pid) as total_cnt     # 聚合函数
from
    product
group by
    category_id;                # 分组字段

# 3.需求3:统计每个类别的商品数量，只显示 商品数量在2 以上的分类
select
    category_id,                # 分组字段
    count(pid) as total_cnt     # 聚合函数
from
    product
group by
    category_id                # 分组字段
having
    count(pid) < 5;

show tables;

# -------------------- 案例6:去重查询 --------------------
/*
去重查询:
    概述:
        把相同的数据，给移除掉，值保留一份
    方式:
        思路1:distinct 关键字实现
        思路2:分组实现
 */
# 1.查看表数据
select * from product;

# 2.查看(去重后)所有的分类id
select distinct category_id from product;

# 3.按照分类id，价格进行去重，是把 category_id和price当作整体 去重(小数据集)
select distinct category_id , price from product;

# 4.去重思路2:分组去重(大数据集)
select category_id from product group by category_id;
select category_id ,price from product group by category_id,price;

# -------------------- 案例7:分页查询 --------------------
/*
分页查询的好处:
    1.提高用户体验
    2.降低服务器压力
    3.降低浏览器压力
语法:
    select * from 数据表名 limit 起始索引，数据条数;
细节:
    1.在sql中，每条数据都是有索引的，且索引从0开始
    2.关于分页，有四个参数的计算规则，需要掌握
        总页数:(数据总条数 + 每页的数据条数 - 1) // 每页的数据条数  (16+3-1)//3=6
        每页的数据条数:n
        每页的起始索引:数据条数n*(当前页数-1)
        数据总条数:count(主键列)
 */
# 1.查看表数据
select * from product;

# 2.场景3: 3条/页
select * from product limit 0,3;        # 第1页
select * from product limit 3,3;        # 第2页
select * from product limit 6,3;        # 第3页
select * from product limit 9,3;        # 第4页
select * from product limit 12,3;        # 第5页
select * from product limit 15,3;        # 第6页