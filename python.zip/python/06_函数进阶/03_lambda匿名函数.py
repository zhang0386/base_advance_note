def func_info(compute):
    x = int(input("输入第一数:"))
    y = int(input("输入第二数:"))
    result = compute(x,y)
    return result


# # lambda一次使用
# print(f"加法{func_info(lambda x,y : x+y)}")
# print(f"减法{func_info(lambda x,y : x-y)}")
# print(f"乘法{func_info(lambda x,y : x*y)}")
# print(f"除法{func_info(lambda x,y : x/y)}")

# 复用需存
operation = lambda x,y:x-y
print(operation(2,3))