# 函数的多返回值
def info():
    return 1,2
x , y = info()
print(x,y)
z = info()
print(z)
print('-'*50)
print("info",end="\n")


# 函数参数
def user_info(name,account,password):
    print(f"用户名:{name}账号:{account}密码:{password}")

# 位置参数
user_info("xiaoming","xio",12345)

# 关键字参数
user_info(name="xiao",account="xie",password=12345)
user_info(account="xiop",name="ming",password=12345)

# 缺省参数
def func(account,password,name = "baidu"):
    print(f"登录网站{name},输入账号:{account},输入密码:{password}")

func("jian",555)
func("kan",693,"Tmat")

# 不定长参数(元组接收)
def fun_info(team,*args):
    print(f"团队名:{team}")
    n = 0
    for i in args:
        n += 1
        print(f"成员{n}:",end="\t")
        print(f"{i}")
fun_info("会想科技","zhan","chen","wang")

# 不定长参数(字典接收)
def func2(team,**kwargs):
    print(type(kwargs))
    print(f"团队名:{team},介绍:{kwargs}")
func2("会想科技",boss="chengyu",time=2026,proverbs="qiang zhe wudi")

# 叠满buff
def func3(name,*args,**kwargs):
    print(f"元组收集:{args}")
    print(f"字典收集:{kwargs}")
func3("会想科技","team","member",boss="chengyu",time=2026,proverbs="qiang zhe wudi")