def func_info(compute):
    x = int(input("输入加数:"))
    y = int(input("输入被加数:"))
    result = compute(x,y)
    return result

def compute(x,y):
    return x + y

print(func_info(compute))