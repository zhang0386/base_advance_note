"""
用f_format实现字符串格式化
"""

name = "haide"
address = "shenzhen"
height = 175.567

message = f"I am {name},live in {address},and height is {height:7.1f}cm."
print(message)