
name = "heide"
height = 175.567
address = "深圳"
message =  "I am %s ,and height is %.2f,live in %s" % (name , height, address)
print(message)

# 精度控制
# m.n    
# - m宽度 - .n四舍五入小数点