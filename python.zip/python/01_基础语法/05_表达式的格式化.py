
age = 11*2-2

info = "字符串在python的变量类型是：%s" % type('字符串')

print("xiaoming‘s age is %d",(3*age/4/2//3))
print(f"小明's age is {age}")
print(info)
