
name = "heide"
age = "20"
address = "newyork"
info = ("I am " + name + "," + str(age) + " age today day," +
        "live in " + str(address))
print(info)