
print("请输入你的微信账号")
account = input()
print("请输入你的微信密码")
password = input()

print("-"*20)

print("截取到的account：%s" % account)
print(f"截取到的passage；{password}")
