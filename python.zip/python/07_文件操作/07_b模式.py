"""
文件操作模式：
  -r:只读
  -w:写入
  -a:追加
  -b:二进制处理

只有文本文件可以使用r，w，a
非文本文件必须带有b，二进制处理
"""

# 打开文件
fr = open(r"文件路径","rb")
fw = open(r"文件路径","wb")

# 复制C盘文件到E盘
# 每次读取4MB(防止内存爆满)
while True:
    data = fr.read(4096*1024)
    if not data:
        break
    fw.write(data)

# 关闭文件
fr.close()
fw.close()

