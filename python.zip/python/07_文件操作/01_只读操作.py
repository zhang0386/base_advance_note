"""
文件操作三大步
1.打开
2.读或写
3.关闭
"""



"""
读取方式一：
"""
f = open("E:\数电实验\hi.txt",'r',encoding="utf-8")

# 全部读取
# content = f.read()
# print(content)
# print(type(content))

# 读取部分
# content = f.read(5)
# print(content)
# print(type(content))

# readlines
# 全部读取，带有换行符
# lst = f.readlines()
# print(lst)
# print(type(lst))

# for line in f.readlines():
#     line = line.strip()     #去除首位的空格和换行
#     print(line)

# readline
# 一次读取一行
print(f.readline().strip())
print(f.readline().strip())
print(f.readline().strip())


f.close()

# """
# 读取方式二：
# """
# with open("E:\数电实验\hi.txt",'r',encoding="ansi") as f:
#     content = f.read()
#     print(content)

