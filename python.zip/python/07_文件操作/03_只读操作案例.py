from collections import Counter

f = open("E:\数电实验\hi.txt",'r',encoding="utf-8")

# 打开文件，读取全部内容
content = f.read()

# 分割单词、统计个数
words = content.split()
res = Counter(words)
print(res)

f.close()