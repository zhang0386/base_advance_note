f = open("E:\数电实验\hi.txt",'a',encoding='utf-8')

f.write("hahaha"+"\n")
f.write("huhuhu"+"\n")

f = open("E:\数电实验\hi.txt",'r',encoding='utf-8')
content = f.read()
print(content)

f.close()