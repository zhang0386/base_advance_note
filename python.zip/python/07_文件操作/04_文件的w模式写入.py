"""

"""
# 打卡文件
f = open("E:\数电实验\word.txt","w",encoding = 'utf-8')

# 将内容写入缓冲区
f.write("hello world")

# 刷新文件
f.flush()

# 关闭文件
f.close()