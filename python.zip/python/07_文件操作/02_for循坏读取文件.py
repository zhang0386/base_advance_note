f = open("E:\数电实验\hi.txt",'r',encoding="utf-8")
for line in f:
    print(line.strip())

# 等同于以下
# for line in f.readlines():
#    print(line.strip())

f.close()