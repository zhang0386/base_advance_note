import time

s = time.time()
f = open("E:\数电实验\word.txt",'w',encoding='utf-8')

for i in range(1000000):
    f.write(str(i)+'\n')
    

f.close()

end = time.time()
print(end - s)