"""
逻辑判断
and or not
"""

database = {
    "zhang" : "13577",
    "li" : "15378"
}
account = input("请输入你的微信账号")
password = input("请输入你的微信密码")

if account == "" or password == "":
    print("账号密码不能为空")
elif account in database and database[account] == password:
    print("登陆成功")
else:
    print("账号密码错误，登陆失败")



age = float(input("请输入你的年龄"))
if age  == "":
    print("输入不能为空")
elif age <= 18:
    print("欢迎游玩")
else:
    print("回家睡觉")



