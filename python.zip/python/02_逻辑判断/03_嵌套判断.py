"""
猜数字游戏
"""
import random
random_num = random.randint(1,20)

num = int(input("在此输入一个1到10的数"))

if num == random_num:
    print("猜对了")

elif  num > random_num:
    num = int(input("喝大了，重新输入"))
    if num == random_num:
        print("猜对了")
    elif num > random_num:
        num = int(input("今天确实喝的有点大，重新输入"))
        if num == random_num:
             print("猜对了")
        else:
            print("猜错了，bitch，go home now,ok？")
    elif num < random_num:
        num = int(input("大，重新输入"))
        if num == random_num:
            print("猜对了")
        else:
            print("猜错了，bitch，go home now,ok？")



elif num < random_num:
    num = int(input("喝少了，重新输入"))
    if num == random_num:
        print("猜对了")
    elif num > random_num:
        num = int(input("今天确实喝的有点shao，重新输入"))
        if num == random_num:
            print("猜对了")
        else:
            print("机会为0，go home now!")
    elif num < random_num:
        num = int(input("小，重新输入"))
        if num == random_num:
            print("猜对了")
        else:
            print("机会为0，go home now!")


else:
    print("输入不能为空或者超出范围")

print(f"random_num is {random_num}")