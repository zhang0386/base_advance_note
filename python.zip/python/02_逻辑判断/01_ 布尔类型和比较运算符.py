
v1 = True
v2 = False
# print(type(v1),type(v2))

print("haide 等于 heide 吗？ %s" % ("haide" == "heide"))
print(f"1+1=3? {1+1==3}")
print("5/2!=1.5? %s" % (5/2!=1.5))
print("5/2>1.5? %s" % (5/2>1.5))
print("5/2>=1.5? %s" % (5/2>=1.5))
print("5/2<1.5? %s" % (5/2<1.5))
print("5/2<=1.5? %s" % (5/2<=1.5))
