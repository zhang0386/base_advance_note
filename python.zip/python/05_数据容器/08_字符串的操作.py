# 字符串和元组一样不可修改元素
s = "w dzj xhz"
print(s[2])

print(s.index('z'))
print(s.index('dzj'))

# replace将原字符串替换成新的
s1 = s.replace(' ','|')
print(s)
print(s1)

# split(分隔符)将字符串分成list
s2 = s.split(' ')
print(s)
print(s2)
print(type(s2))
print(s2[2])

# strip()去除字符串的前后空格
s3 = " w l g xhz "
s3 = s3.strip()
print(s3)

# strip(字符)去除字符串的前后指定字符
s4 = "|||w l g xhz|||"
s5 = s4.strip('|')
print(s4)
print(s5)
s6 = s4.replace('|','')
print(s6)

# count()统计字符串中的元素个数
s7 = "wo le ge ge ge xiaohzi"
print(s7.count("ge"))

# len()统计字符串长度
s8 = "wo le ge xhz"
print(len(s8))

# 字符串的遍历
t = 0
while t < 12:
    print(s8[t])
    t += 1
print('-'*20)
for i in s8:
    print(i)