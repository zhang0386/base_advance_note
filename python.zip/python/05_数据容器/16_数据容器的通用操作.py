# 定义数据容器
lit = [2,1,3,2,7,5]
tup = (1,5,2,7,10,9)
str_d = '18367'
set_y = {8,6,3,4,2,5}
dit = {"1":10,"3":20,"2":30}

# 转列表
print('-'*20,"转列表",'-'*20)
print(f"{lit}转列表{list(lit)}")
print(f"{tup}转列表{list(tup)}")
print(f"{str_d}转列表{list(str_d)}")
print(f"{set_y}转列表{list(set_y)}")
print(f"{dit}转列表{list(dit)}")

# 转元组
print('-'*20,"转元组",'-'*20)
print(f"{lit}转元组{tuple(lit)}")
print(f"{tup}转元组{tuple(tup)}")
print(f"{str_d}转元组{tuple(str_d)}")
print(f"{set_y}转元组{tuple(set_y)}")
print(f"{dit}转元组{tuple(dit)}")

# 转字符串
print('-'*20,"转字符串",'-'*20)
print(f"{lit}转字符串{str(lit)}")
print(f"{tup}转字符串{str(tup)}")
print(f"{str_d}转字符串{str(str_d)}")
print(f"{set_y}转字符串{str(set_y)}")
print(f"{dit}转字符串{str(dit)}")

# 转集合
print('-'*20,"转集合",'-'*20)
print(f"{lit}转集合{set(lit)}")
print(f"{tup}转集合{set(tup)}")
print(f"{str_d}转集合{set(str_d)}")
print(f"{set_y}转集合{set(set_y)}")
print(f"{dit}转集合{set(dit)}")

# 排序
# sorted(容器,[reverse=Ture])
print('-'*20,"排序",'-'*20)
print(f"{lit}排序后{sorted(lit)}")
print(f"{tup}排序后{sorted(tup)}")
print(f"{str_d}排序后{sorted(str_d)}")
print(f"{set_y}排序后{sorted(set_y)}")
print(f"{dit}排序后{sorted(dit)}")