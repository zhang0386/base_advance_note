"""
集合可去重并且乱序
"""

st = {1,2,3,5,"xhz",5,True,False,0}
print(st,type(st))

# 集合不允许下标索引

# 空集合
st1 = set()
print(st1,type(st1))