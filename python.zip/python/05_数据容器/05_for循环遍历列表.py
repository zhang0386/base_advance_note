lit = [12,13,14,15,16]

for i in lit:
    print(i)