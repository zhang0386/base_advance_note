"""
列表本质上一个类，内部提供了很多内置函数（称之为方法）
这些内置函数（方法）的使用，需要用
列表变量.内置函数
"""
lit = ["zhan","python","qiangzhe","wudi"]
print(lit.index("python"))       # index函数是查找列表下标的函数

"""
快捷操作：元素是否在列表内
元素 in 列表
"""
print("wudi" in lit)
print("qiangzhewudi" in lit)

# 修改列表元素
lit1 = [1,2,6]
lit1[0] = 2
lit1[2] = 3
print("lit1",lit1)

# 在列表中插入元素
my_lit = [5,6,7]
my_lit.insert(1,"hanshu")
print("my_lit",my_lit)
my_lit.insert(5,"whf")
print("my_lit",my_lit)

# 在列表尾部新增元素
lit2 = [11,12,13]
lit2.append('HLXT')
print("lit2",lit2)

# 在列表尾部新增一批元素
lit3 = [11,12,13]
lit3.extend([14,15,16,'nihao'])
print("lit3",lit3)

# del删掉列表内的元素
lit4 = [10,20,30,40,50,60,70,80,90]
del lit4[1]
print(" ",lit4)
# pop删掉列表内的元素，与del不同的是pop有返回值
delete_data = lit4.pop(3)
print(f"      被删掉的元素是{delete_data}")
print("lit4",lit4)

# 删掉列表中的第一个匹配项
# 传入的是元素而不是下标
lit5 = [24,25,27,26,27]
lit5.remove(27)
print("lit5",lit5)

# 清空列表内容
lit6 = [33,34,35,36,37]
lit6 = []            # 或者lit6.clear()
print("lit6",lit6)

# 统计列表内的某个元素个数
lit7 = [27,24,25,27,26,27,27,27]
print("lit7中27的个数是:",lit7.count(27))

# 统计列表内的元素
lit8 = [27,24,25,27,26,27,27,27]
print("lit8中元素的个数是:",len(lit8))