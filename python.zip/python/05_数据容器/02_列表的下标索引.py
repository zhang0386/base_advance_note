"""
正向索引
"""
name_lit = ["zhan","qiang","zhe"]
print(name_lit[0])
print(name_lit[1])
print(name_lit[2])

print('-'*20)
"""
反向索引
"""
print(name_lit[-1])
print(name_lit[-2])
print(name_lit[-3])

"""
嵌套索引
"""
lit = [[1,2,3],[4,5,6],[7,8,9]]
print(lit[1][2])
print(lit[0][-2])