"""
字典
key：value
不支持下标引用
"""

# 空字典
d = {}
print(type(d))
di = dict()
print(type(di))

# 定义字典
password = {'zan':12345,
            'gpo':12568,
            'jop':32562}
print(password['zan'])

account = input("请输入账号：")
print('获取的密码是：',password[account])


