from lib2to3.pygram import python_grammar_no_print_statement
from time import process_time

from numpy.testing.print_coercion_tables import print_new_cast_table
from pyvista import get_gpu_info

message = {
    "wang":{"部门":"科技部","工资":3000,"级别":1},
    "zhou":{"部门":"市场部","工资":5000,"级别":2},
    "lin":{"部门":"市场部","工资":7000,"级别":3},
    "zhang":{"部门":"科技部","工资":4000,"级别":1},
    "liu":{"部门":"市场部","工资":6000,"级别":2}
}

for i in message.keys():
    if message[i]["级别"] == 1:
        message[i]["级别"] += 1
        message[i]["工资"] += 1000
        print(f"{i}由原级别{message[i]['级别'] - 1}升级别为{message[i]['级别']}")
        print(f"{i}由工资{message[i]['工资'] - 1000}升工资为{message[i]['工资']}")


print('-'*20,"update_message",'-'*20)
for name,info in message.items():
    print(f"{name}:{info}")


