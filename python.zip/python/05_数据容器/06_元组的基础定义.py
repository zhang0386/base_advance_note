"""
元组和列表的区别是无法改变元素
"""
t1 = (1,2,3,'abc')
print(t1)
print("t1的类型:",type(t1))

# 得到空元组
t1 = ()
t2 = tuple()
print(t1)
print(t2)
print("t1的类型:%s t2的类型:%s" % (type(t1),type(t2)))

# 只有一个元素的写法
t3 = (1,)
print("t3的类型：",type(t1))
