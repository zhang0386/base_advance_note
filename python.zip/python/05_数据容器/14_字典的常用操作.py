password = {'zan':12345,
            'gpo':12568,
            'jop':32562}

# 新增字典
password["jun"] = 88888
print(password)

# 更新字典
password['zan'] = 23456
print(password)

# 删除字典
d = password.pop('jop')
print("删除的字典的value是：",d)
print(password)

# 清空字典
password.clear()
print(password)
print('-'*20)

password = {'zan':12345,
            'gpo':12568,
            'jop':32562}

# 遍历字典方式1
print(password.keys())
for i in password.keys():
    print(f"账户:{i},密码:{password[i]}")
print('-'*20)

# 遍历字典方式2
for i in password:
    print(f"账户:{i},密码:{password[i]}")
print('-'*20)

# 统计字典的长度
print(f"字典的长度为：{len(password)}")