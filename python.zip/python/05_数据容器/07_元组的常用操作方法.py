from operator import index

t1 = (1,2,3,4,5)
print(t1.index(3))

t2 = (1,3,4,5,2,1,2)
print(t2.count(2))