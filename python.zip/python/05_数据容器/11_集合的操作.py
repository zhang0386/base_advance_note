"""
集合是无序存储的，不支持下标索引和重复存在
"""
# 添加元素
my_set = {"z","f","q","z"}
my_set.add("v")
print(my_set)
print('-'*20)

# 去除元素
my_set.remove("f")
print(my_set)
print('-'*20)

# pop()随机取出一个元素,此元素在集合中删除
print('随机元素是',my_set.pop())
print(my_set)
print('-'*20)

# 清空集合
my_set.clear()
print(my_set)
print('-'*20)

# 取set1和set2的差集
# 集合1.difference(set2)
# 取集合2没有的
set1 = { 1 , 2 ,3 }
set2 = { 1 , 4 ,5 }
set3 = set1.difference(set2)
print("差集：",set3)
print(set1)
print(set2)
print('-'*20)

# 修改set1中与set2的相同元素
set4 = set1.difference_update(set2)
print('消去',set4)
print('原集合1',set1)
print('原集合2',set2)
print('-'*20)

# 并集
set5 = set1.union(set2)
print('并集',set5)
print('原集合1',set1)
print('原集合2',set2)
print('-'*20)

# 统计集合个数
my_set = {"z","f","q","z"}
print('my_set的长度为',len(my_set))
print('-'*20)

# 遍历循环，只能用for
my_set = {"z","f","q","z"}
n = 0
for i in my_set:
    print(i)
    n += 1
print('遍历次数',n)