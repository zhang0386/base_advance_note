"""
字典的key和value可以是任意类型（key不能是数据容器）
"""
stu_score = {
    "xiaoming":{"语文":99,"数学":98,"英语":100},
    "xiaojun":{"语文":97,"数学":100,"英语":95},
    "xiaoqing":{"语文":100,"数学":97,"英语":97}
}
subject = input("输入你想查阅的学生科目成绩：")
student = input("输入你想查阅的学生成绩：")
if subject == " ":
    print(f"{student}的成绩为：")
    print(stu_score[student])
else:
    print(f"{student}的{subject}成绩为：")
    print(stu_score[student][subject])