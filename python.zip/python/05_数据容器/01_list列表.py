
lit = [1,2,3,4,5]

print(lit)

lit1 = [1,'a','小黑子']

print(lit1)

#list的嵌套使用
lit4 = [ [1,2,3] ,["a","b","c"] ]
print(lit4)
print(type(lit4))
