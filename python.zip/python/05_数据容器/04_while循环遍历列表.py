lit = [12,13,14,15,16]
index = 0

while index < len(lit):
    print(lit[index])
    index += 1