
num = 0

while num<10:
    print("第%d次拦截成功" % (num+1))


    num += 1
