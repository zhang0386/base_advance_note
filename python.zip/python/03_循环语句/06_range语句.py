"""
range(num1[,num2[,step]])
"""
for i in range(5):
    print(i,end=" ")
print()
print("-"*20)
for j in range(5,10):
    print(j,end=" ")
print()
print("-"*20)
for k in range(1,10,2):
    print(k,end=" ")
