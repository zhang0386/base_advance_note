"""
安全：拦截恶意弹窗
"""
from itertools import count

period = 1

while period <=100:
    print("第%d次拦截" % period)

    count = 1
    while count <= 10:
        print(f"测试{count}次识别到恶意弹窗，请求拦截")
        count += 1

    period += 1

print("\n网站安全")