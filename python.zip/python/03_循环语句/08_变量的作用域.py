

for num in range(5):

    print("发送请求")
    print(num)

