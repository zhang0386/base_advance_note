"""
for 临时变量 in 待处理数据集
"""
password = "zhang0351nihao ya wu shuangwan ahajia"
i = 0

for x in password:
    if x == 'a':
        i += 1
print("目标字符串中有%d个a" % i)