"""
默认end="\n"
"""

print("向目标网站发送请求,",end="")
print("请求成功",end="\n")

"""
  table键
"""
print("ab\t请求")
print("abc\t拦截")


