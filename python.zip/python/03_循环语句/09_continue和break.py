#
# for i in range(1,11):
#     flag = int(input(f"第{i}次检索，检索到密码，检索到为1，未检索到为0 "))
#     if flag == 0:
#         print("获取失败")
#         continue
#     print("获取成功")

"""
加入外层循环，同时使用break终止循环
"""
for j in range(1,6):
    for i in range(1,11):
        flag = int(input(f"第{j}次纵向检索第{i}次横向检索，检索到密码，检索到为1，未检索到为0 "))
        if flag == 0:
            print("获取失败")
            break
        print("获取成功")
