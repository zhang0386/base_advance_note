"""
用while循环打印九九乘法表
"""
# row = 1
#
# while row <10:
#     col = 1
#     while col <= row:
#           print(f"{col}*{row}={col*row}",end="\t")
#           col += 1
#     print("\n")
#     row += 1

"""
用for循环打印九九乘法表
"""
row = 1
col = 1
for row in range(1,10):
    for col in range(1,row+1):
        print(f"{col}*{row}={col*row}",end=" ")

    print()
    col = 1
    row += 1