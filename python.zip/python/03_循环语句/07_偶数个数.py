j=0
for i in range(1,100):
    if i%2==0:
        j += 1

print(f"1到99的偶数个数为{j}个")

print("-"*20)
n = 0
for i in range(0,99,2):
    print(i,end=" ")
    n += 1
print()
print(f"1到99的偶数个数为{n-1}个")

