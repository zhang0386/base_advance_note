try:
    print(1+2)
except Exception as e:
    print("异常报错，错误是:",e)
else:
    print("正常运行")