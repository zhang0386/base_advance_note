from pyecharts import options as opts
from pyecharts.charts import Line

# 准备数据
x_data = ["1月", "2月", "3月", "4月", "5月", "6月"]
y_data = [120, 200, 150, 80, 70, 110]

# 创建折线图
line = (
    Line()
    .add_xaxis(x_data)  # X轴数据
    .add_yaxis("月度销量", y_data)  # Y轴数据，系列名称
    .set_global_opts(
        title_opts=opts.TitleOpts(title="商品月度销量折线图"), # 图表标题
        xaxis_opts=opts.AxisOpts(axislabel_opts=opts.LabelOpts(rotate=15)), # X轴标签旋转
        tooltip_opts=opts.TooltipOpts(trigger="axis"), # 鼠标悬浮提示
    )
)

# 渲染生成 html 文件，运行后会在同目录产出 line_demo.html
line.render("折线图示例.html")
print("图表已生成：折线图示例.html，请打开文件查看！")