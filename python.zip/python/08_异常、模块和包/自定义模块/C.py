# __all__是内置变量，默认为all
# __all__ =['info','rel']

def info():
    print("厚礼蟹，下的发卡")

def rel():
    print("relly gain shit")

def mi():
    print("gain gain")

