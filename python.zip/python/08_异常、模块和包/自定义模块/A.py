import B

# B.say_hi()
# res = B.add(2,3)
# print(res)
# B.cheer()
#
# print(B.name)
# print(B.account)
# print(B.password)

from C import *
rel()
info()
mi()