def say_hi():
    print("hello")

def cheer():
    for i in  range(5):
        print("wuhu")

def add(x,y):
    num = x + y
    return num

gre = None
name = "zan"
account = "hlx"
password = 12345678

# 以下程序只会在本文件执行，其他文件调用该模块不会执行以下程序
if __name__ =='__main__':
    say_hi()