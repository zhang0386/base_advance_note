import pygame
import random
import sys

# 初始化pygame
pygame.init()

# 基础设置
WIDTH, HEIGHT = 400, 400
BLOCK_SIZE = 20
SPEED = 10

# 颜色定义
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
DARK_GREEN = (0, 180, 0)
RED = (255, 0, 0)

# 创建窗口
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pygame 贪吃蛇")
clock = pygame.time.Clock()

# ==========【修复重点】替换字体创建方式，避开SysFont的bug ==========
# 不用 SysFont(None,35)，改用系统固定字体名称
try:
    font = pygame.font.SysFont("simhei", 35)
except:
    font = pygame.font.Font(pygame.font.get_default_font(), 35)


def show_score(score):
    text = font.render(f"分数: {score}", True, WHITE)
    screen.blit(text, [0, 0])


def draw_snake(block_size, snake_list):
    for index, pos in enumerate(snake_list):
        # 蛇头深色
        if index == 0:
            pygame.draw.rect(screen, DARK_GREEN, [pos[0], pos[1], block_size, block_size])
        else:
            pygame.draw.rect(screen, GREEN, [pos[0], pos[1], block_size, block_size])


def game_loop():
    game_over = False
    game_close = False

    # 蛇初始坐标
    x, y = WIDTH / 2, HEIGHT / 2
    dx, dy = 0, 0

    snake_list = []
    snake_length = 1

    # 随机食物
    food_x = round(random.randrange(0, WIDTH - BLOCK_SIZE) / BLOCK_SIZE) * BLOCK_SIZE
    food_y = round(random.randrange(0, HEIGHT - BLOCK_SIZE) / BLOCK_SIZE) * BLOCK_SIZE

    while not game_over:
        # 游戏结束弹窗
        while game_close:
            screen.fill(BLACK)
            msg = font.render("游戏结束！Q退出 / C重新开始", True, RED)
            screen.blit(msg, [WIDTH//10, HEIGHT//3])
            show_score(snake_length - 1)
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:  # Q退出
                        game_over = True
                        game_close = False
                    if event.key == pygame.K_c:  # C重开
                        game_loop()
                if event.type == pygame.QUIT:
                    game_over = True
                    game_close = False

        # 监听窗口关闭、按键
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT and dx != BLOCK_SIZE:
                    dx = -BLOCK_SIZE
                    dy = 0
                elif event.key == pygame.K_RIGHT and dx != -BLOCK_SIZE:
                    dx = BLOCK_SIZE
                    dy = 0
                elif event.key == pygame.K_UP and dy != BLOCK_SIZE:
                    dy = -BLOCK_SIZE
                    dx = 0
                elif event.key == pygame.K_DOWN and dy != -BLOCK_SIZE:
                    dy = BLOCK_SIZE
                    dx = 0

        # 撞墙判定
        if x >= WIDTH or x < 0 or y >= HEIGHT or y < 0:
            game_close = True

        x += dx
        y += dy
        screen.fill(BLACK)

        # 绘制食物
        pygame.draw.rect(screen, RED, [food_x, food_y, BLOCK_SIZE, BLOCK_SIZE])

        # 更新蛇头
        snake_head = [x, y]
        snake_list.append(snake_head)

        # 保持蛇长度
        if len(snake_list) > snake_length:
            del snake_list[0]

        # 撞到自己
        for seg in snake_list[:-1]:
            if seg == snake_head:
                game_close = True

        draw_snake(BLOCK_SIZE, snake_list)
        show_score(snake_length - 1)
        pygame.display.update()

        # 吃到食物
        if x == food_x and y == food_y:
            food_x = round(random.randrange(0, WIDTH - BLOCK_SIZE) / BLOCK_SIZE) * BLOCK_SIZE
            food_y = round(random.randrange(0, HEIGHT - BLOCK_SIZE) / BLOCK_SIZE) * BLOCK_SIZE
            snake_length += 1

        clock.tick(SPEED)

    pygame.quit()
    sys.exit()


if __name__ == "__main__":
    game_loop()