# 方式一
# try:
#     1/0
# except (FileNotFoundError,ZeroDivisionError) as e:
#     print("异常报错，异常是：",e)

# 方式二
try:
    password = { }
    print(password['zan'])
except FileNotFoundError as e:
    print("文件不存在",e)
except ZeroDivisionError as e:
    print("除零错误",e)
except KeyError as e:
    print("字典key异常",e)
