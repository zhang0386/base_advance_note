# 捕获除零错误异常
try:
    1/0
except ZeroDivisionError as e:
    print("除零异常",e)

# 捕获文件不存在异常
try:
    f = open(r"E:\数电实验\flat.txt",'r',encoding='utf-8')
except FileNotFoundError as a:
    print("文件不存在",a)
