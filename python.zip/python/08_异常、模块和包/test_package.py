# import my_package.moudle1 as m1
# import my_package.moudle2 as m2

# my_package.moudle1.hi()
# my_package.moudle2.info()

# m1.hi()
# m2.info()
#
# from my_package import moudle1
# moudle1.hi()
#
# from my_package.moudle1 import hi
# hi()

from my_package import *
moudle1.hi()
moudle2.info()