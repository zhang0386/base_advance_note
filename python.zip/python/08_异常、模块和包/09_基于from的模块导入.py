"""
from 模块名 import 功能 [as 别名]
"""

# 仅导入了randint函数
from random import randint

print(randint(1, 10))

# 导入模块的全部功能
from random import *

print(randint(1, 10))
print(choice(['a', 'b']))