f = None
try:
    # 异常预案
    f = open(r"E:\数电实验\hello.txt",'r',encoding="utf-8")
except:
    # 问题解决方案
    f = open(r"E:\数电实验\hello.txt",'w',encoding="utf-8")


print(f.read())

f.close()