
try:
    open('chang','r')
except Exception as e:
    print("异常报错，错误是:",e)