# 内置的__all__默认为None
__all__ = ['moudle1','moudle2']