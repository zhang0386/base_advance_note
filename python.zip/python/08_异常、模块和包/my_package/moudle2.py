

def info():
    print("厚礼蟹")