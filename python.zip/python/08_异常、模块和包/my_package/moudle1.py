

def hi():
    print("world!")