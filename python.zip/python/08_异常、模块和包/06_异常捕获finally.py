"""
try:出现的异常
except:异常预案
else:无异常处理
finally:无论是否出现异常，都执行
"""

try:
    1+1
except Exception as e:
    print("异常报错，错误是:",e)
else:
    print('一切正常')
finally:
    print("程序执行完毕")
