
def info2():
    print("info2start")
    1/0
    print("info2end")

def info1():
    print("info1start")
    info2()
    print("info1end")

def main():
    info1()

try:
    main()
except Exception as e:
    print("异常报错，异常是:",e)