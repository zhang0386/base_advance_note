import pygame
import random
import sys
import os

# 让窗口在屏幕正中打开
os.environ['SDL_VIDEO_CENTERED'] = '1'

pygame.init()

# ========== 设置 ==========
WINDOW_WIDTH = 800
WINDOW_HEIGHT = 600
CELL_SIZE = 20
GRID_W = WINDOW_WIDTH // CELL_SIZE
GRID_H = WINDOW_HEIGHT // CELL_SIZE

# 颜色
BG = (20, 20, 20)
GRID_COLOR = (45, 45, 45)
HEAD = (0, 220, 0)
BODY = (0, 160, 0)
FOOD = (220, 60, 60)
TEXT = (255, 255, 255)

# 方向
UP = (0, -1)
DOWN = (0, 1)
LEFT = (-1, 0)
RIGHT = (1, 0)

screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("贪吃蛇")
clock = pygame.time.Clock()

# 使用 pygame 内置默认字体（兼容性最好）
font_big = pygame.font.Font(None, 72)
font_mid = pygame.font.Font(None, 40)
font_small = pygame.font.Font(None, 30)

print("=" * 50)
print("贪吃蛇游戏启动成功！")
print("如果窗口没显示，请按 Alt+Tab 切换，或去任务栏找")
print("=" * 50)


class Snake:
    def __init__(self):
        x, y = GRID_W // 2, GRID_H // 2
        self.body = [(x, y), (x - 1, y), (x - 2, y)]
        self.dir = RIGHT
        self.next_dir = RIGHT
        self.grow = False

    def turn(self, d):
        if d != (-self.dir[0], -self.dir[1]):
            self.next_dir = d

    def move(self):
        self.dir = self.next_dir
        hx, hy = self.body[0]
        new_head = (hx + self.dir[0], hy + self.dir[1])
        self.body.insert(0, new_head)
        if not self.grow:
            self.body.pop()
        self.grow = False

    def add(self):
        self.grow = True

    def dead(self):
        hx, hy = self.body[0]
        if hx < 0 or hx >= GRID_W or hy < 0 or hy >= GRID_H:
            return True
        if self.body[0] in self.body[1:]:
            return True
        return False

    def draw(self, surf):
        for i, (x, y) in enumerate(self.body):
            px, py = x * CELL_SIZE, y * CELL_SIZE
            color = HEAD if i == 0 else BODY
            r = pygame.Rect(px + 1, py + 1, CELL_SIZE - 2, CELL_SIZE - 2)
            pygame.draw.rect(surf, color, r, border_radius=4)

            # 画眼睛
            if i == 0:
                offset = 5
                if self.dir in (LEFT, RIGHT):
                    ex = px + CELL_SIZE // 2 + self.dir[0] * 4
                    pygame.draw.circle(surf, (255, 255, 255), (ex, py + offset), 3)
                    pygame.draw.circle(surf, (255, 255, 255), (ex, py + CELL_SIZE - offset), 3)
                else:
                    ey = py + CELL_SIZE // 2 + self.dir[1] * 4
                    pygame.draw.circle(surf, (255, 255, 255), (px + offset, ey), 3)
                    pygame.draw.circle(surf, (255, 255, 255), (px + CELL_SIZE - offset, ey), 3)


class Food:
    def __init__(self, snake_body):
        self.pos = self.new_pos(snake_body)

    def new_pos(self, body):
        while True:
            p = (random.randint(0, GRID_W - 1), random.randint(0, GRID_H - 1))
            if p not in body:
                return p

    def draw(self, surf):
        x, y = self.pos[0] * CELL_SIZE, self.pos[1] * CELL_SIZE
        r = pygame.Rect(x + 2, y + 2, CELL_SIZE - 4, CELL_SIZE - 4)
        pygame.draw.rect(surf, FOOD, r, border_radius=6)


def draw_grid(surf):
    for x in range(0, WINDOW_WIDTH, CELL_SIZE):
        pygame.draw.line(surf, GRID_COLOR, (x, 0), (x, WINDOW_HEIGHT))
    for y in range(0, WINDOW_HEIGHT, CELL_SIZE):
        pygame.draw.line(surf, GRID_COLOR, (0, y), (WINDOW_WIDTH, y))


def draw_text(surf, text, font, color, center):
    img = font.render(text, True, color)
    rect = img.get_rect(center=center)
    surf.blit(img, rect)


def main():
    snake = Snake()
    food = Food(snake.body)
    score = 0
    high = 0
    speed = 10
    game_over = False

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if game_over:
                    if event.key == pygame.K_r:
                        # 重新开始
                        snake = Snake()
                        food = Food(snake.body)
                        score = 0
                        speed = 10
                        game_over = False
                    elif event.key == pygame.K_ESCAPE:
                        running = False
                else:
                    if event.key in (pygame.K_UP, pygame.K_w):
                        snake.turn(UP)
                    elif event.key in (pygame.K_DOWN, pygame.K_s):
                        snake.turn(DOWN)
                    elif event.key in (pygame.K_LEFT, pygame.K_a):
                        snake.turn(LEFT)
                    elif event.key in (pygame.K_RIGHT, pygame.K_d):
                        snake.turn(RIGHT)
                    elif event.key == pygame.K_ESCAPE:
                        running = False

        if not game_over:
            snake.move()
            if snake.dead():
                game_over = True
                if score > high:
                    high = score

            if snake.body[0] == food.pos:
                snake.add()
                score += 10
                food = Food(snake.body)
                if score % 50 == 0:
                    speed = min(speed + 1, 20)

        # ========== 绘制 ==========
        screen.fill(BG)
        draw_grid(screen)
        food.draw(screen)
        snake.draw(screen)

        # 分数
        score_txt = font_small.render(f"Score: {score}   High: {high}", True, TEXT)
        screen.blit(score_txt, (10, 10))

        if game_over:
            overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
            overlay.set_alpha(180)
            overlay.fill((0, 0, 0))
            screen.blit(overlay, (0, 0))
            draw_text(screen, "GAME OVER", font_big, (255, 80, 80), (WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2 - 40))
            draw_text(screen, f"Score: {score}", font_mid, TEXT, (WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2 + 20))
            draw_text(screen, "R: Restart   ESC: Quit", font_small, TEXT, (WINDOW_WIDTH // 2, WINDOW_HEIGHT // 2 + 70))

        pygame.display.flip()
        clock.tick(speed)

    pygame.quit()
    print("游戏已退出")


if __name__ == "__main__":
    main()