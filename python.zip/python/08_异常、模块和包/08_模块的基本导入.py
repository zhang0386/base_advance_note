"""
import 模块名
-模块名：.py内置文件

导入之后
模块名.函数
模块名.变量
模块名.类
"""

import time as t
import random

print(t.time())  # t是time的别名
print(random.randint(1, 10))

print("account")
t.sleep(5)
print("password")