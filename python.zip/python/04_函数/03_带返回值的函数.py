
def add(x,y):
    result = x + y
    return result

r = add(1,5)
print(r)
