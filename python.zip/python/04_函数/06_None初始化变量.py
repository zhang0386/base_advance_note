password = None
for i in range(1,6):
    password = input("请输入你的账号密码")
    print(f"你的账号密码是{password}")
