account = "hanzhng"
length = len(account)
print(f"账号的长度为 {length}")  #len为内置函数

"""
len可以等同于下面函数
函数的定义
def 函数名(传入参数):
    函数体
    return 返回值
"""
def my_len(data):
    length = 0
    for i in data:
        length += 1
    return length

info = "hanzhngn"
print(f"{info}的长度为 {my_len(info)}")

message = "今天你好吗"
print(f"{message}的长度为 {my_len(message)}")

name = "天天开心"
print(f"{name}的长度为 {my_len(name)}")