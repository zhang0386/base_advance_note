"""
局部变量：定义在函数内部的变量
全局变量：定义在函数2外部的变量
"""
num = None

def func():
    # global num
    # 加了这句第一句定义的全局变量会被下面的num重新赋值
    # print("全局变量",num)
    num = 1
    print("局部变量",num)

func()
print("全局变量",num)
