
money = 1000000

name = input("请输入你的名字:")
print(f"{name},你好，这里是会想银行atm，")

def menu():
    """
    打印主菜单
    :return: 数字号码
    """
    print("-" * 10, "主菜单", "-" * 10)
    print("查询余额\t[请按1]")
    print("取款\t\t[请按2]")
    print("取款\t\t[请按3]")
    print("退出\t\t[请按4]")
    return input("请输入你的选择")


def query_money(title):
    """
    查询余额
    :param title: 判断是否打印的参数
    :return: None
    """
    if title:
        print("-" * 10, "查询余额", "-" * 10)
    print(f"你的余额是{money}")

def save_money():
    global money
    print("-" * 10, "存款", "-" * 10)
    num = int(input("你存入的金额是："))
    money += num
    query_money(False)

def take_money():
    """
    存款
    :return: None
    """
    global money
    print("-" * 10, "取款", "-" * 10)
    num = int(input("你要取出的金额是："))
    if num <= money:
        money -= num
    else:
        print("余额不足")
    query_money(False)


def func_d():
    """
    退出函数
    :return: None
    """
    print("退出成功")

while 1:
    b = menu()
    if b == '1':
       query_money(True)
    elif b == '2':
       save_money()
    elif b == '3':
       take_money()
    elif b=='4':
       func_d()
       break
    else:
       print("输入错误")
