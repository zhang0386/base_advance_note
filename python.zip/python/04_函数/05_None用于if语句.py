
def capture(x):
    if x>0:
        return "获取成功"
    return None


if capture(-1):
    print("SUCCESS")
else:
    print("False")