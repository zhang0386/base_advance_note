
def add(x,y):

    print(f"{x}+{y}={x + y}")

add(5,40)

add("kilo","meter")