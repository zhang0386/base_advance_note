def add(x,y):
    """
    两数相加
    :param x: 加数1
    :param y: 加数2
    :return: 两数相加的结果
    """
    return x+y

r = add(5,7)
print(r)