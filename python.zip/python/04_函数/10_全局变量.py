num = 10

def func():
    print(f"a:{num}")

def func_1():
    print(f"b:{num}")

func_1()
func()