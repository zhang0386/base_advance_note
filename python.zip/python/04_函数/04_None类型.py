"""
返回值为空
"""
def capture():
    print("获取成功")

result = capture()
print(result)
print(type(result))

print("-"*20)

def capture():
    print("获取成功")
    return None

result = capture()
print(result)
print(type(result))